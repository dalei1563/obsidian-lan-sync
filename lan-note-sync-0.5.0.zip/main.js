"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => LanSyncPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian3 = require("obsidian");
var import_node_path6 = require("node:path");
var import_node_os = require("node:os");

// shared/protocol.ts
var import_node_crypto = require("node:crypto");
var PROTOCOL = 2;
var MAX_BYTES = 5 * 1024 * 1024;
var MAX_FILES = 1e4;
var id = () => (0, import_node_crypto.randomUUID)();
var hash = (data) => (0, import_node_crypto.createHash)("sha256").update(data).digest("hex");
var validCursor = (value) => typeof value === "number" && Number.isSafeInteger(value) && value >= 0 || typeof value === "string" && value.length > 0 && value.length <= 2048;
var SyncError = class extends Error {
  constructor(code, message, status = 409) {
    super(message);
    this.code = code;
    this.status = status;
  }
};
function validId(value) {
  return typeof value === "string" && /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,95}$/.test(value) && !Object.prototype.hasOwnProperty.call(Object.prototype, value);
}
function assertId(value) {
  if (!validId(value)) throw new SyncError("invalid_id", "\u6807\u8BC6\u65E0\u6548", 400);
}
function assertHash(value) {
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/.test(value)) throw new SyncError("invalid_hash", "\u5185\u5BB9\u54C8\u5E0C\u65E0\u6548", 400);
}
function validatePath(value) {
  if (typeof value !== "string" || value.length > 512 || value !== value.normalize("NFC") || !value.endsWith(".md")) {
    throw new SyncError("invalid_path", "\u4EC5\u652F\u6301 NFC \u683C\u5F0F\u7684\u76F8\u5BF9 .md \u8DEF\u5F84\uFF08\u6700\u957F 512 \u5B57\u7B26\uFF09", 400);
  }
  const segments = value.split("/");
  if (segments.some((s) => !s || s.startsWith(".") || s !== s.trim() || /[. ]$/.test(s) || /[\\<>:"|?*\x00-\x1f\x7f]/.test(s) || s.length > 200 || /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(s))) {
    throw new SyncError("invalid_path", "\u8DEF\u5F84\u5305\u542B\u9690\u85CF\u76EE\u5F55\u3001\u4FDD\u7559\u540D\u79F0\u6216\u975E\u6CD5\u5B57\u7B26", 400);
  }
  return value;
}
var pathKey = (path) => path.normalize("NFC").toLowerCase();
function validateRevision(input) {
  const r = input;
  if (!r || typeof r !== "object") throw new SyncError("invalid_revision", "\u4FEE\u8BA2\u65E0\u6548", 400);
  assertId(r.id);
  assertId(r.fileId);
  assertId(r.clientId);
  validatePath(r.path);
  if (!Array.isArray(r.parents) || r.parents.length > 32 || new Set(r.parents).size !== r.parents.length) {
    throw new SyncError("invalid_parents", "\u7236\u4FEE\u8BA2\u5217\u8868\u65E0\u6548", 400);
  }
  r.parents.forEach(assertId);
  if (r.parents.includes(r.id) || typeof r.deleted !== "boolean" || !Number.isInteger(r.size) || r.size < 0 || r.size > MAX_BYTES) {
    throw new SyncError("invalid_revision", "\u4FEE\u8BA2\u5B57\u6BB5\u65E0\u6548", 400);
  }
  if (r.deleted) {
    if (r.hash !== null || r.size !== 0) throw new SyncError("invalid_delete", "\u5220\u9664\u4FEE\u8BA2\u4E0D\u80FD\u5305\u542B\u6B63\u6587", 400);
  } else assertHash(r.hash);
  return {
    id: r.id,
    fileId: r.fileId,
    parents: [...r.parents].sort(),
    path: r.path,
    deleted: r.deleted,
    hash: r.hash,
    size: r.size,
    clientId: r.clientId
  };
}

// src/settings.ts
var import_obsidian = require("obsidian");

// shared/exclusions.ts
function normalizeExclusions(input) {
  if (!Array.isArray(input) || input.length > 64) throw new SyncError("invalid_exclusions", "\u6392\u9664\u89C4\u5219\u5FC5\u987B\u662F\u6570\u7EC4\uFF0C\u6700\u591A 64 \u6761", 400);
  const result = [], seen = /* @__PURE__ */ new Set();
  for (const item of input) {
    if (typeof item !== "string") throw new SyncError("invalid_exclusions", "\u6BCF\u6761\u6392\u9664\u89C4\u5219\u5FC5\u987B\u662F\u6587\u672C", 400);
    let rule = item.trim().normalize("NFC").replace(/\\/g, "/");
    if (!rule) continue;
    if (rule.startsWith("./")) rule = rule.slice(2);
    if (rule.endsWith("/")) rule += "**";
    const parts = rule.split("/");
    if (rule.length > 256 || !rule || /[\x00-\x1f\x7f<>:"|\[\]{}]/.test(rule) || parts.some((p) => !p || p === "." || p === ".." || p.includes("**") && p !== "**")) {
      throw new SyncError("invalid_exclusions", "\u6392\u9664\u89C4\u5219\u9700\u4F7F\u7528\u76F8\u5BF9\u8DEF\u5F84\uFF1B\u652F\u6301 *\u3001?\u3001** \u548C\u76EE\u5F55\u672B\u5C3E /\uFF0C\u6700\u957F 256 \u5B57\u7B26", 400);
    }
    const key = rule.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      result.push(rule);
    }
  }
  return result;
}
function segmentMatches(pattern, text) {
  let p = 0, t = 0, star = -1, retry = 0;
  while (t < text.length) {
    if (pattern[p] === "?" || pattern[p] === text[t]) {
      p++;
      t++;
    } else if (pattern[p] === "*") {
      star = p++;
      retry = t;
    } else if (star >= 0) {
      p = star + 1;
      t = ++retry;
    } else return false;
  }
  while (pattern[p] === "*") p++;
  return p === pattern.length;
}
function pathMatches(pattern, path) {
  let previous = Array(path.length + 1).fill(false);
  previous[0] = true;
  for (const part of pattern) {
    const next = Array(path.length + 1).fill(false);
    if (part === "**") {
      next[0] = previous[0];
      for (let i = 1; i <= path.length; i++) next[i] = previous[i] || next[i - 1];
    } else for (let i = 1; i <= path.length; i++) next[i] = previous[i - 1] && segmentMatches(part, path[i - 1]);
    previous = next;
  }
  return previous[path.length];
}
function isExcluded(path, rules, configDir = ".obsidian") {
  const parts = path.normalize("NFC").replace(/\\/g, "/").toLowerCase().split("/");
  if (parts.some((p) => p.startsWith("."))) return true;
  const config = configDir.replace(/\\/g, "/").toLowerCase().split("/");
  if (config.every((p, i) => parts[i] === p)) return true;
  for (const rule of rules) {
    const pattern = rule.toLowerCase().split("/");
    if (pattern.length === 1 && pattern[0] !== "**") {
      if (parts.some((part) => segmentMatches(pattern[0], part))) return true;
    } else if (pathMatches(pattern, parts)) return true;
  }
  return false;
}

// src/settings.ts
var DEFAULT_SETTINGS = {
  server: "http://127.0.0.1:27123",
  allowHttp: false,
  enabled: false,
  vaultId: "",
  vaultName: "",
  deviceId: "",
  serverId: "",
  secretId: "",
  excludedPaths: [],
  autoUpdate: true,
  storageLimitMiB: 1024,
  storageSample: null
};
var LanSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
    this.connectionDraft = "";
  }
  updateStatus(message) {
    if (!this.plugin.unloaded) this.statusEl?.setText(message);
  }
  refreshBinding() {
    if (!this.plugin.unloaded && this.containerEl.isConnected) this.display();
  }
  display() {
    if (this.plugin.unloaded) return;
    const { containerEl } = this, plugin = this.plugin;
    containerEl.empty();
    containerEl.addClass("lan-sync-settings");
    containerEl.createEl("h2", { text: "\u81EA\u5DF1\u7684\u7B14\u8BB0\u540C\u6B65" });
    containerEl.createEl("p", { text: "\u5728 Windows \u548C macOS \u4E4B\u95F4\u540C\u6B65 Markdown \u7B14\u8BB0\u3002\u6BCF\u4E2A\u672C\u5730\u7B14\u8BB0\u5E93\u53EF\u72EC\u7ACB\u8FDE\u63A5\u81EA\u5DF1\u7684\u8FDC\u7AEF\u4ED3\u5E93\uFF0C\u590D\u5236\u8BE5\u4ED3\u5E93\u7684\u8FDE\u63A5\u7801\u5373\u53EF\u5F00\u59CB\u3002" });
    const card = containerEl.createDiv("lan-sync-card");
    this.statusEl = card.createEl("strong", { text: plugin.status });
    if (!plugin.settings.vaultId) {
      new import_obsidian.Setting(containerEl).setName("\u8FDE\u63A5\u7801").setDesc("\u6BCF\u53F0\u8BBE\u5907\u4F7F\u7528\u65B0\u7684\u4E00\u6B21\u6027\u8FDE\u63A5\u7801\u3002\u591A\u8BBE\u5907\u540C\u6B65\u540C\u4E00\u4ED3\u5E93\u65F6\uFF0C\u8BF7\u5728\u540E\u53F0\u7684\u540C\u4E00\u4ED3\u5E93\u5206\u522B\u751F\u6210\u65B0\u7801\u3002\u7C98\u8D34 lansync: \u5B8C\u6574\u8FDE\u63A5\u7801\uFF1B\u901A\u8FC7\u5B89\u88C5\u547D\u4EE4\u63A5\u5165\u65F6\u4F1A\u81EA\u52A8\u586B\u5199\u3002").addTextArea((t) => {
        t.setValue(this.connectionDraft).setPlaceholder("lansync:\u2026").onChange((v) => {
          this.connectionDraft = v;
        });
        t.inputEl.rows = 3;
        t.inputEl.style.width = "100%";
        t.inputEl.setAttribute("spellcheck", "false");
      });
      new import_obsidian.Setting(containerEl).addButton((b) => b.setButtonText(plugin.connecting ? "\u6B63\u5728\u8FDE\u63A5\u2026" : "\u8FDE\u63A5\u5E76\u9884\u89C8").setDisabled(plugin.connecting).setCta().onClick(() => {
        b.setDisabled(true);
        void plugin.action(() => plugin.importConnection(this.connectionDraft.trim())).finally(() => {
          if (!plugin.unloaded) {
            b.setDisabled(false);
            this.refreshBinding();
          }
        });
      }));
    } else {
      card.createEl("p", { text: `\u5DF2\u8FDE\u63A5\uFF1A${plugin.settings.vaultName}` });
      new import_obsidian.Setting(containerEl).setName(plugin.engine?.state.initialized ? "\u8986\u76D6\u540C\u6B65" : "\u9996\u6B21\u540C\u6B65").setDesc("\u9009\u62E9\u4E91\u7AEF\u6216\u672C\u5730\u4F5C\u4E3A\u51C6\uFF0C\u5404\u9879\u4FEE\u6539\u548C\u5220\u9664\u4F1A\u5148\u663E\u793A\u4F9B\u4F60\u786E\u8BA4\u3002").addButton((b) => b.setButtonText(plugin.previewing ? "\u6B63\u5728\u83B7\u53D6\u9884\u89C8\u2026" : "\u9009\u62E9\u5E76\u9884\u89C8").setDisabled(plugin.previewing).setCta().onClick(() => {
        b.setDisabled(true);
        void plugin.action(() => plugin.preview()).finally(() => {
          if (!plugin.unloaded) {
            b.setDisabled(false);
            this.refreshBinding();
          }
        });
      }));
      new import_obsidian.Setting(containerEl).setName("\u81EA\u52A8\u540C\u6B65").setDesc("\u6B63\u5E38\u5199\u4F5C\u5373\u53EF\uFF1B\u65AD\u7F51\u540E\u4F1A\u5728\u6062\u590D\u8FDE\u63A5\u65F6\u91CD\u8BD5\u3002").addToggle((t) => t.setValue(plugin.settings.enabled).setDisabled(!plugin.engine?.state.initialized || !!plugin.engine?.state.overwrite).onChange(async (enabled) => {
        plugin.settings.enabled = enabled;
        await plugin.saveSettings();
        plugin.setStatus(enabled ? "\u7B49\u5F85\u540C\u6B65" : "\u81EA\u52A8\u540C\u6B65\u5DF2\u6682\u505C");
        if (enabled) await plugin.sync(true);
      }));
      new import_obsidian.Setting(containerEl).addButton((b) => b.setButtonText("\u7ACB\u5373\u540C\u6B65").setCta().onClick(() => void plugin.action(() => plugin.sync(true)))).addButton((b) => b.setButtonText("\u67E5\u770B\u5F85\u5904\u7406\u9879").onClick(() => void plugin.action(() => plugin.showIssues())));
      new import_obsidian.Setting(containerEl).setName("\u63D2\u4EF6\u81EA\u52A8\u66F4\u65B0").setDesc("\u4ECE\u5DF2\u8FDE\u63A5\u7684\u540C\u6B65\u670D\u52A1\u68C0\u67E5\u5E76\u4E0B\u8F7D\u65B0\u7248\uFF0C\u91CD\u542F Obsidian \u540E\u751F\u6548\uFF1B\u7B14\u8BB0\u548C\u8FDE\u63A5\u914D\u7F6E\u4F1A\u4FDD\u7559\u3002").addToggle((t) => t.setValue(plugin.settings.autoUpdate).onChange(async (enabled) => {
        plugin.settings.autoUpdate = enabled;
        await plugin.saveSettings();
      }));
      new import_obsidian.Setting(containerEl).addButton((b) => b.setButtonText("\u68C0\u67E5\u63D2\u4EF6\u66F4\u65B0").onClick(() => void plugin.action(() => plugin.checkUpdate(true))));
    }
    containerEl.createEl("h3", { text: "\u6392\u9664\u540C\u6B65" });
    containerEl.createEl("p", { text: ".obsidian\u3001\u5F53\u524D\u914D\u7F6E\u76EE\u5F55\u548C\u9690\u85CF\u76EE\u5F55\u59CB\u7EC8\u4E0D\u53C2\u4E0E\u540C\u6B65\u3002\u4EE5\u4E0B\u89C4\u5219\u4EC5\u4F5C\u7528\u4E8E\u5F53\u524D\u672C\u5730\u7B14\u8BB0\u5E93\uFF0C\u5E76\u4E0E\u540E\u53F0\u4ED3\u5E93\u89C4\u5219\u5408\u5E76\u3002\u65B0\u589E\u6392\u9664\u89C4\u5219\u4F1A\u6682\u505C\u76F8\u5173\u6587\u4EF6\u7684\u4E0A\u4F20\u3001\u4E0B\u8F7D\u548C\u5220\u9664\uFF1B\u5DF2\u540C\u6B65\u5185\u5BB9\u4F1A\u4FDD\u7559\u3002" });
    if (this.exclusionDraft === void 0) this.exclusionDraft = plugin.settings.excludedPaths.join("\n");
    new import_obsidian.Setting(containerEl).setName("\u672C\u673A\u989D\u5916\u6392\u9664\u89C4\u5219").setDesc("\u6BCF\u884C\u4E00\u6761\uFF0C\u4F8B\u5982 private/\u3001**/\u8349\u7A3F/**\u3001*.tmp.md\uFF1B\u652F\u6301 *\u3001? \u548C **\u3002").addTextArea((t) => {
      t.setValue(this.exclusionDraft).setPlaceholder("private/\n**/\u8349\u7A3F/**\n*.tmp.md").onChange((v) => {
        this.exclusionDraft = v;
      });
      t.inputEl.rows = 4;
      t.inputEl.style.width = "100%";
      t.inputEl.setAttribute("spellcheck", "false");
    });
    new import_obsidian.Setting(containerEl).addButton((b) => b.setButtonText("\u4FDD\u5B58\u6392\u9664\u89C4\u5219").onClick(() => {
      b.setDisabled(true);
      void plugin.action(async () => {
        plugin.settings.excludedPaths = normalizeExclusions(this.exclusionDraft.split(/\r?\n/));
        await plugin.saveSettings();
        this.exclusionDraft = plugin.settings.excludedPaths.join("\n");
        plugin.setStatus("\u6392\u9664\u89C4\u5219\u5DF2\u4FDD\u5B58");
        if (plugin.settings.enabled) await plugin.sync(true);
        this.display();
      }).finally(() => {
        if (!plugin.unloaded) b.setDisabled(false);
      });
    }));
    const serverRules = plugin.engine?.state.serverExcludedPaths ?? [];
    if (serverRules.length) containerEl.createEl("p", { text: "\u540E\u53F0\u4ED3\u5E93\u6392\u9664\u89C4\u5219\uFF1A" + serverRules.join("\uFF1B") });
    const details = containerEl.createEl("details");
    details.createEl("summary", { text: "\u8FDE\u63A5\u8BCA\u65AD\u4E0E\u6062\u590D" });
    details.createEl("p", { text: "\u6253\u5F00\u4E2D\u7684\u7B14\u8BB0\u4F1A\u7B49\u5F85\u5173\u95ED\u540E\u518D\u63A5\u6536\u8FDC\u7AEF\u66FF\u6362\u3002\u5386\u53F2\u7248\u672C\u53EF\u5728\u7BA1\u7406\u5458\u540E\u53F0\u67E5\u770B\u548C\u6062\u590D\u3002" });
    if (plugin.settings.vaultId) {
      details.createEl("p", { text: `\u670D\u52A1\uFF1A${plugin.settings.server}\uFF1B\u8BBE\u5907\uFF1A${plugin.settings.deviceId.slice(0, 8)}` });
      new import_obsidian.Setting(details).addButton((b) => b.setButtonText("\u68C0\u67E5\u8FDE\u63A5").onClick(() => void plugin.action(async () => {
        await plugin.diagnose();
        this.display();
      })));
    }
    if (plugin.disk) details.createEl("code", { text: plugin.disk.directory + "/snapshots" });
    if (plugin.disk && plugin.engine) {
      let limit = String(plugin.settings.storageLimitMiB);
      new import_obsidian.Setting(details).setName("\u5BB9\u91CF\u544A\u8B66\u9608\u503C\uFF08MiB\uFF09").setDesc("\u4EFB\u4E00\u7EDF\u8BA1\u9879\u8FBE\u5230\u6B64\u503C\u65F6\u63D0\u793A\uFF1B0 \u8868\u793A\u5173\u95ED\u544A\u8B66\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u6E05\u7406\u3002").addTextArea((t) => {
        t.setValue(limit).onChange((value) => {
          limit = value;
        });
        t.inputEl.rows = 1;
      });
      new import_obsidian.Setting(details).addButton((b) => b.setButtonText("\u4FDD\u5B58\u9608\u503C").onClick(() => void plugin.action(async () => {
        const value = Number(limit);
        if (!Number.isFinite(value) || value < 0 || value > 1e7) throw new Error("\u8BF7\u8F93\u5165\u6709\u6548\u7684\u975E\u8D1F\u5BB9\u91CF\u9608\u503C");
        plugin.settings.storageLimitMiB = value;
        await plugin.saveSettings();
        new import_obsidian.Notice("\u5BB9\u91CF\u544A\u8B66\u9608\u503C\u5DF2\u4FDD\u5B58");
      }))).addButton((b) => b.setButtonText("\u67E5\u770B\u5BB9\u91CF").onClick(() => void plugin.action(() => plugin.showStorage())));
      new import_obsidian.Setting(details).setName("\u6E05\u7406\u672C\u673A\u6062\u590D\u5FEB\u7167").setDesc("\u53EA\u6E05\u7406\u672C\u63D2\u4EF6\u4FDD\u5B58\u7684\u6062\u590D\u526F\u672C\uFF1B\u9884\u89C8\u548C\u786E\u8BA4\u540E\u6C38\u4E45\u5220\u9664\uFF0C\u65E0\u6CD5\u4ECE\u672C\u673A\u6062\u590D\u3002").addButton((b) => b.setButtonText("\u9884\u89C8\u6E05\u7406").onClick(() => void plugin.action(() => plugin.previewSnapshotCleanup())));
    }
    details.createEl("p", { text: "\u51ED\u8BC1\u4FDD\u5B58\u5728 Obsidian \u5BC6\u94A5\u5B58\u50A8\u4E2D\u3002\u4E0D\u8981\u5220\u9664\u540C\u6B65\u72B6\u6001\u6765\u4FEE\u590D\u8FDE\u63A5\uFF0C\u4E5F\u4E0D\u8981\u540C\u65F6\u5BF9\u8FD9\u4E2A Vault \u542F\u7528\u5176\u4ED6\u540C\u6B65\u63D2\u4EF6\u3002" });
  }
};

// src/sync/disk-state.ts
var import_node_fs = require("node:fs");
var import_node_path = require("node:path");
var DiskState = class {
  constructor(directory) {
    this.failure = false;
    this.owner = JSON.stringify({ pid: process.pid, instance: id() });
    this.directory = (0, import_node_path.resolve)(directory);
    let current = this.directory;
    while (current !== (0, import_node_path.resolve)(current, "..")) {
      if ((0, import_node_fs.existsSync)(current) && (0, import_node_fs.lstatSync)(current).isSymbolicLink()) throw new Error("\u72B6\u6001\u76EE\u5F55\u4E0D\u80FD\u7ECF\u8FC7\u7B26\u53F7\u94FE\u63A5");
      current = (0, import_node_path.resolve)(current, "..");
    }
    (0, import_node_fs.mkdirSync)(this.directory, { recursive: true });
    (0, import_node_fs.mkdirSync)((0, import_node_path.join)(this.directory, "snapshots"), { recursive: true });
    const lock = (0, import_node_path.join)(this.directory, "state.lock");
    if ((0, import_node_fs.existsSync)(lock)) {
      let pid;
      try {
        pid = JSON.parse((0, import_node_fs.readFileSync)(lock, "utf8")).pid;
      } catch {
        throw new Error("\u72B6\u6001\u9501\u635F\u574F\uFF0C\u8BF7\u4FDD\u7559\u76EE\u5F55\u5E76\u68C0\u67E5\u8FD0\u884C\u4E2D\u7684 Obsidian");
      }
      let alive = true;
      try {
        process.kill(pid, 0);
      } catch (e) {
        if (e.code === "ESRCH") alive = false;
      }
      if (alive || !pid) throw new Error("\u6B64 Vault \u7684\u540C\u6B65\u4EFB\u52A1\u4ECD\u5728\u8FD0\u884C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      (0, import_node_fs.unlinkSync)(lock);
    }
    (0, import_node_fs.writeFileSync)(lock, this.owner, { flag: "wx", mode: 384 });
  }
  load() {
    const path = (0, import_node_path.join)(this.directory, "state.json");
    if (!(0, import_node_fs.existsSync)(path)) return null;
    let s;
    try {
      s = JSON.parse((0, import_node_fs.readFileSync)(path, "utf8"));
    } catch {
      throw new Error("\u540C\u6B65\u72B6\u6001\u635F\u574F\uFF0C\u5DF2\u6682\u505C\u3002\u8BF7\u4FDD\u7559 local-state \u76EE\u5F55\uFF0C\u52FF\u5220\u9664\u540E\u76F4\u63A5\u91CD\u7ED1\u3002");
    }
    if (s && s.schema !== 1) throw new Error("\u540C\u6B65\u72B6\u6001\u7248\u672C\u4E0D\u517C\u5BB9\uFF0C\u5DF2\u6682\u505C\u3002\u8BF7\u4FDD\u7559 local-state \u76EE\u5F55\u5E76\u4F7F\u7528\u5339\u914D\u7684\u63D2\u4EF6\u7248\u672C\u3002");
    try {
      if (!s || !s.entries || !s.remote || !Array.isArray(s.pending) || !validCursor(s.cursor)) throw new Error();
      return s;
    } catch {
      throw new Error("\u540C\u6B65\u72B6\u6001\u635F\u574F\uFF0C\u5DF2\u6682\u505C\u3002\u8BF7\u4FDD\u7559 local-state \u76EE\u5F55\uFF0C\u52FF\u5220\u9664\u540E\u76F4\u63A5\u91CD\u7ED1\u3002");
    }
  }
  async save(state) {
    if (this.failure) throw new Error("\u672C\u5730\u72B6\u6001\u5199\u5165\u66FE\u5931\u8D25\uFF0C\u9700\u4FEE\u590D\u78C1\u76D8\u5E76\u91CD\u65B0\u52A0\u8F7D\u63D2\u4EF6");
    try {
      this.atomic((0, import_node_path.join)(this.directory, "state.json"), Buffer.from(JSON.stringify(state)));
    } catch {
      this.failure = true;
      throw new Error("\u65E0\u6CD5\u6301\u4E45\u5316\u540C\u6B65\u72B6\u6001\uFF0C\u5DF2\u505C\u6B62\u7F51\u7EDC\u63D0\u4EA4\uFF1B\u8BF7\u68C0\u67E5\u78C1\u76D8\u540E\u91CD\u65B0\u52A0\u8F7D\u63D2\u4EF6");
    }
  }
  atomic(path, data) {
    const temp = path + "." + id() + ".tmp";
    const fd = (0, import_node_fs.openSync)(temp, "wx", 384);
    try {
      (0, import_node_fs.writeFileSync)(fd, data);
      (0, import_node_fs.fsyncSync)(fd);
    } finally {
      (0, import_node_fs.closeSync)(fd);
    }
    (0, import_node_fs.renameSync)(temp, path);
    if (process.platform !== "win32") {
      const dir = (0, import_node_fs.openSync)((0, import_node_path.dirname)(path), "r");
      try {
        (0, import_node_fs.fsyncSync)(dir);
      } finally {
        (0, import_node_fs.closeSync)(dir);
      }
    }
  }
  async preserve(data) {
    const target = (0, import_node_path.join)(this.directory, "snapshots", hash(data) + ".md");
    if (!(0, import_node_fs.existsSync)(target)) this.atomic(target, data);
    else if (hash((0, import_node_fs.readFileSync)(target)) !== hash(data)) throw new Error("\u6062\u590D\u5FEB\u7167\u635F\u574F\uFF0C\u8BF7\u68C0\u67E5\u78C1\u76D8");
  }
  previewSnapshotCleanup() {
    const directory = (0, import_node_path.join)(this.directory, "snapshots");
    if ((0, import_node_fs.lstatSync)(directory).isSymbolicLink()) throw new Error("\u6062\u590D\u5FEB\u7167\u76EE\u5F55\u4E0D\u80FD\u662F\u94FE\u63A5");
    const files = (0, import_node_fs.readdirSync)(directory).sort().map((name) => {
      if (!/^[a-f0-9]{64}\.md$/.test(name)) throw new Error("\u5FEB\u7167\u76EE\u5F55\u5305\u542B\u672A\u77E5\u6587\u4EF6\uFF0C\u5DF2\u505C\u6B62\u6E05\u7406");
      const file = (0, import_node_path.join)(directory, name), stat = (0, import_node_fs.lstatSync)(file);
      if (!stat.isFile() || stat.isSymbolicLink() || hash((0, import_node_fs.readFileSync)(file)) !== name.slice(0, 64)) throw new Error("\u5FEB\u7167\u76EE\u5F55\u5305\u542B\u65E0\u6548\u6216\u635F\u574F\u6587\u4EF6\uFF0C\u5DF2\u505C\u6B62\u6E05\u7406");
      return { name, size: stat.size };
    });
    return { files, fingerprint: hash(JSON.stringify(files)) };
  }
  cleanupSnapshots(fingerprint) {
    const plan = this.previewSnapshotCleanup();
    if (plan.fingerprint !== fingerprint) throw new Error("\u5FEB\u7167\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u6E05\u7406");
    let removed = 0;
    try {
      for (const item of plan.files) {
        const path = (0, import_node_path.join)(this.directory, "snapshots", item.name), stat = (0, import_node_fs.lstatSync)(path);
        if (!stat.isFile() || stat.isSymbolicLink() || hash((0, import_node_fs.readFileSync)(path)) !== item.name.slice(0, 64)) throw new Error("\u5FEB\u7167\u5DF2\u53D8\u5316");
        (0, import_node_fs.unlinkSync)(path);
        removed++;
      }
    } catch {
      throw new Error(`\u6E05\u7406\u5DF2\u505C\u6B62\uFF0C\u5DF2\u5220\u9664 ${removed} \u4E2A\u5FEB\u7167\uFF1B\u8BF7\u91CD\u65B0\u9884\u89C8\u540E\u68C0\u67E5`);
    }
    return removed;
  }
  close() {
    const lock = (0, import_node_path.join)(this.directory, "state.lock");
    if ((0, import_node_fs.existsSync)(lock) && (0, import_node_fs.readFileSync)(lock, "utf8") === this.owner) (0, import_node_fs.unlinkSync)(lock);
  }
};

// src/sync/overwrite-plan.ts
function planOverwrite(mode, local, snapshot, excluded) {
  if (mode !== "cloud-to-local" && mode !== "local-to-cloud") throw new Error("\u8986\u76D6\u65B9\u5411\u65E0\u6548");
  const locals = /* @__PURE__ */ new Map();
  for (const [path, bytes] of local) {
    if (excluded(path)) continue;
    const key = pathKey(path);
    if (locals.has(key)) throw new Error(`\u672C\u5730\u8DEF\u5F84\u5927\u5C0F\u5199\u51B2\u7A81\uFF1A${path}`);
    locals.set(key, { path, hash: hash(bytes) });
  }
  const clouds = /* @__PURE__ */ new Map();
  for (const file of snapshot.files) {
    if (file.heads.some((h) => excluded(h.path))) continue;
    if (file.heads.length !== 1) throw new Error("\u4E91\u7AEF\u5B58\u5728\u591A\u4E2A\u51B2\u7A81\u7248\u672C\uFF0C\u8BF7\u5148\u5728\u5BA2\u6237\u7AEF\u5904\u7406\u51B2\u7A81\uFF0C\u518D\u6267\u884C\u8986\u76D6");
    const head = file.heads[0];
    if (head.deleted) continue;
    const key = pathKey(head.path);
    if (clouds.has(key)) throw new Error(`\u4E91\u7AEF\u5B58\u5728\u91CD\u590D\u8DEF\u5F84\uFF1A${head.path}`);
    clouds.set(key, head);
  }
  const actions = [];
  let unchanged = 0;
  for (const [key, item] of locals) {
    const remote = clouds.get(key);
    if (remote && remote.path !== item.path) throw new Error(`\u4E24\u7AEF\u8DEF\u5F84\u5927\u5C0F\u5199\u4E0D\u540C\uFF0C\u8BF7\u5148\u7EDF\u4E00\u540D\u79F0\uFF1A${item.path}`);
    if (remote && remote.hash === item.hash) {
      unchanged++;
      continue;
    }
    if (mode === "local-to-cloud") actions.push({ type: "upload", path: item.path, localHash: item.hash, remote: remote ?? null });
    else if (remote) actions.push({ type: "download", path: remote.path, localHash: item.hash, remote });
    else actions.push({ type: "delete-local", path: item.path, localHash: item.hash, remote: null });
  }
  for (const [key, remote] of clouds) if (!locals.has(key)) {
    actions.push({ type: mode === "cloud-to-local" ? "download" : "delete-cloud", path: remote.path, localHash: null, remote });
  }
  actions.sort((a, b) => Number(!a.type.startsWith("delete-")) - Number(!b.type.startsWith("delete-")) || a.path.localeCompare(b.path));
  const fingerprint = hash(JSON.stringify({
    mode,
    serverId: snapshot.serverId,
    epoch: snapshot.epoch,
    cursor: snapshot.cursor,
    local: [...locals].sort(([a], [b]) => a.localeCompare(b)),
    cloud: [...clouds].sort(([a], [b]) => a.localeCompare(b))
  }));
  return { mode, local: locals.size, cloud: clouds.size, unchanged, actions, fingerprint };
}

// src/sync/engine.ts
function newState(serverId, vaultId, clientId) {
  return { schema: 1, serverId, vaultId, clientId, initialized: false, epoch: "", cursor: 0, remote: {}, entries: {}, pending: [], issues: {} };
}
var Engine = class {
  constructor(remote, local, state, save, report = () => {
  }, options = {}) {
    this.remote = remote;
    this.local = local;
    this.state = state;
    this.save = save;
    this.report = report;
    this.options = options;
    this.tail = Promise.resolve();
    this.stopped = false;
    if (state.schema !== 1 || state.vaultId !== remote.vaultId) throw new Error("\u672C\u5730\u540C\u6B65\u72B6\u6001\u4E0D\u5339\u914D\uFF0C\u5DF2\u505C\u6B62");
    if (state.serverExcludedPaths !== void 0) state.serverExcludedPaths = normalizeExclusions(state.serverExcludedPaths);
  }
  isExcluded(path) {
    return isExcluded(path, [...this.state.serverExcludedPaths ?? [], ...normalizeExclusions([...this.options.excludedPaths?.() ?? []])], this.options.configDir);
  }
  policy(rules) {
    if (rules !== void 0 || this.state.serverExcludedPaths === void 0) this.state.serverExcludedPaths = normalizeExclusions(rules ?? []);
  }
  async scan() {
    const files = await this.local.scan((path) => !this.isExcluded(path));
    return new Map([...files].filter(([path]) => !this.isExcluded(path)));
  }
  async previewOverwrite(mode) {
    if (this.state.pending.length || Object.keys(this.state.issues).length) throw new Error("\u8BF7\u5148\u5904\u7406\u5F85\u4E0A\u4F20\u5185\u5BB9\u548C\u51B2\u7A81\uFF0C\u518D\u6267\u884C\u8986\u76D6");
    if (this.state.overwrite && this.state.overwrite.plan.mode !== mode) throw new Error("\u5DF2\u6709\u672A\u5B8C\u6210\u7684\u8986\u76D6\uFF0C\u8BF7\u5148\u5B8C\u6210\u539F\u6765\u7684\u65B9\u5411");
    const snapshot = await this.remote.snapshot();
    this.checkIdentity(snapshot);
    this.policy(snapshot.excludedPaths);
    return planOverwrite(mode, await this.scan(), snapshot, (path) => this.isExcluded(path));
  }
  startOverwrite(plan) {
    return this.exclusive(async () => {
      if (this.stopped) throw new Error("\u540C\u6B65\u5DF2\u505C\u6B62\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u63D2\u4EF6");
      const snapshot = await this.remote.snapshot();
      this.checkIdentity(snapshot);
      this.policy(snapshot.excludedPaths);
      if (this.state.pending.length || Object.keys(this.state.issues).length) throw new Error("\u8BF7\u5148\u5904\u7406\u5F85\u4E0A\u4F20\u5185\u5BB9\u548C\u51B2\u7A81\uFF0C\u518D\u6267\u884C\u8986\u76D6");
      if (this.state.overwrite && this.state.overwrite.plan.mode !== plan.mode) throw new Error("\u5DF2\u6709\u672A\u5B8C\u6210\u7684\u8986\u76D6\uFF0C\u8BF7\u5148\u5B8C\u6210\u539F\u6765\u7684\u65B9\u5411");
      const fresh = planOverwrite(plan.mode, await this.scan(), snapshot, (path) => this.isExcluded(path));
      if (fresh.fingerprint !== plan.fingerprint) throw new Error("\u9884\u89C8\u540E\u7B14\u8BB0\u6216\u4E91\u7AEF\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8");
      await this.local.assertClosed?.(fresh.actions.map((a) => a.path));
      this.state.overwrite = {
        plan: fresh,
        epoch: snapshot.epoch,
        cursor: snapshot.cursor,
        index: 0,
        operationIds: fresh.actions.map(() => id()),
        fileIds: fresh.actions.map((a) => a.remote?.fileId ?? id())
      };
      await this.save(this.state);
      await this.runOverwrite();
    });
  }
  resumeOverwrite() {
    return this.exclusive(() => this.runOverwrite());
  }
  async runOverwrite() {
    const job = this.state.overwrite;
    if (!job || !Array.isArray(job.plan?.actions) || !Array.isArray(job.operationIds) || !Array.isArray(job.fileIds) || !Number.isInteger(job.index) || job.index < 0 || job.index > job.plan.actions.length || job.operationIds.length !== job.plan.actions.length || job.fileIds.length !== job.plan.actions.length) throw new Error("\u8986\u76D6\u4EFB\u52A1\u65E0\u6548\uFF0C\u8BF7\u4FDD\u7559\u672C\u5730\u72B6\u6001\u5E76\u8054\u7CFB\u7BA1\u7406\u5458");
    if (!["cloud-to-local", "local-to-cloud"].includes(job.plan.mode)) throw new Error("\u8986\u76D6\u4EFB\u52A1\u65B9\u5411\u65E0\u6548");
    for (let i = 0; i < job.plan.actions.length; i++) {
      const a = job.plan.actions[i];
      validatePath(a.path);
      assertId(job.operationIds[i]);
      assertId(job.fileIds[i]);
      if (a.localHash !== null) assertHash(a.localHash);
      if (a.remote !== null) {
        const remote = validateRevision(a.remote);
        if (remote.deleted || remote.path !== a.path || remote.fileId !== job.fileIds[i]) throw new Error("\u8986\u76D6\u4EFB\u52A1\u8FDC\u7AEF\u7248\u672C\u65E0\u6548");
      }
      if (job.plan.mode === "cloud-to-local" && !(a.type === "delete-local" && a.localHash !== null && !a.remote || a.type === "download" && !!a.remote)) throw new Error("\u8986\u76D6\u4EFB\u52A1\u64CD\u4F5C\u65E0\u6548");
      if (job.plan.mode === "local-to-cloud" && !(a.type === "delete-cloud" && a.localHash === null && !!a.remote || a.type === "upload" && a.localHash !== null)) throw new Error("\u8986\u76D6\u4EFB\u52A1\u64CD\u4F5C\u65E0\u6548");
    }
    for (; job.index < job.plan.actions.length; ) {
      if (this.stopped) throw new Error("\u8986\u76D6\u5DF2\u6682\u505C\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u63D2\u4EF6\u7EE7\u7EED");
      const action = job.plan.actions[job.index];
      if (this.isExcluded(action.path)) throw new Error("\u6392\u9664\u89C4\u5219\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u8986\u76D6");
      await this.local.assertClosed?.([action.path]);
      const local = await this.local.read(action.path), currentHash = local === null ? null : hash(local);
      if (job.plan.mode === "cloud-to-local") {
        const remote = await this.remote.snapshot();
        this.checkIdentity(remote);
        this.policy(remote.excludedPaths);
        if (remote.epoch !== job.epoch || remote.cursor !== job.cursor || this.isExcluded(action.path)) throw new Error("\u4E91\u7AEF\u5DF2\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u8986\u76D6");
        const targetHash = action.type === "delete-local" ? null : action.remote?.hash ?? null;
        if (currentHash !== targetHash) {
          if (currentHash !== action.localHash) throw new Error(`\u672C\u5730\u7B14\u8BB0\u5DF2\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\uFF1A${action.path}`);
          const content = action.type === "delete-local" ? null : await this.remote.get(action.remote.hash);
          await this.local.apply({ oldPath: action.path, path: action.path, expectedHash: action.localHash, content });
        }
      } else {
        if (currentHash !== action.localHash) throw new Error(`\u672C\u5730\u7B14\u8BB0\u5DF2\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\uFF1A${action.path}`);
        const deleted = action.type === "delete-cloud", parents = action.remote ? [action.remote.id] : [];
        const revision = {
          id: job.operationIds[job.index],
          fileId: job.fileIds[job.index],
          parents,
          path: action.path,
          deleted,
          hash: deleted ? null : currentHash,
          size: deleted ? 0 : local.length,
          clientId: this.state.clientId
        };
        if (!deleted) await this.remote.put(local, currentHash);
        await this.remote.commitStrict(revision, parents);
      }
      job.index++;
      await this.save(this.state);
      this.report(`\u6B63\u5728\u8986\u76D6 ${job.index}/${job.plan.actions.length}`);
    }
    const final = await this.remote.snapshot();
    this.checkIdentity(final);
    this.policy(final.excludedPaths);
    const files = await this.scan(), remaining = planOverwrite(job.plan.mode, files, final, (path) => this.isExcluded(path));
    if (remaining.actions.length) throw new Error("\u8986\u76D6\u671F\u95F4\u4E24\u7AEF\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\u5E76\u7EE7\u7EED");
    const entries = Object.fromEntries(Object.entries(this.state.entries).filter(([, e]) => this.isExcluded(e.path)));
    const live = new Map(final.files.flatMap((f) => f.heads.length === 1 && !f.heads[0].deleted ? [[pathKey(f.heads[0].path), f.heads[0]]] : []));
    for (const [path, bytes] of files) {
      const head = live.get(pathKey(path));
      if (!head || head.path !== path || head.hash !== hash(bytes)) throw new Error(`\u4E24\u7AEF\u5C1A\u672A\u4E00\u81F4\uFF0C\u8BF7\u91CD\u65B0\u9884\u89C8\uFF1A${path}`);
      entries[head.fileId] = { fileId: head.fileId, path, basePath: path, baseRevision: head.id, baseHash: head.hash, baseDeleted: false, materialized: true };
    }
    this.state.entries = entries;
    this.state.remote = Object.fromEntries(final.files.map((f) => [f.fileId, f]));
    this.state.epoch = final.epoch;
    this.state.cursor = final.cursor;
    this.state.initialized = true;
    delete this.state.overwrite;
    this.state.issues = {};
    await this.save(this.state);
    this.report("\u8986\u76D6\u5B8C\u6210\uFF0C\u5DF2\u540C\u6B65");
  }
  exclusive(action) {
    const result = this.tail.then(action);
    this.tail = result.catch(() => {
    });
    return result;
  }
  stop() {
    this.stopped = true;
    return this.tail;
  }
  checkIdentity(s) {
    if (s.serverId !== this.state.serverId) throw new Error("\u670D\u52A1\u7AEF\u8EAB\u4EFD\u5DF2\u53D8\u5316\uFF0C\u8BF7\u68C0\u67E5\u5730\u5740\u6216\u5907\u4EFD\u6062\u590D\u60C5\u51B5");
  }
  async snapshot() {
    const s = await this.remote.snapshot();
    this.checkIdentity(s);
    this.policy(s.excludedPaths);
    const bases = Object.values(this.state.entries).filter((e) => !!e.baseRevision);
    const known = await this.remote.known([...new Set(bases.map((e) => e.baseRevision))]);
    for (const entry of bases) if (!known.has(entry.baseRevision)) {
      entry.blocked = "\u670D\u52A1\u5668\u7F3A\u5C11\u672C\u5730\u5DF2\u786E\u8BA4\u7684\u5386\u53F2\u7248\u672C\uFF08\u53EF\u80FD\u6062\u590D\u4E86\u65E7\u5907\u4EFD\uFF09\uFF0C\u8BF7\u9009\u62E9\u7248\u672C\u6216\u6062\u590D\u5B8C\u6574\u670D\u52A1\u7AEF\u5907\u4EFD";
    }
    this.state.remote = Object.fromEntries(s.files.map((f) => [f.fileId, f]));
    this.state.cursor = s.cursor;
    this.state.epoch = s.epoch;
    await this.save(this.state);
  }
  async preview() {
    const snapshot = await this.remote.snapshot();
    this.checkIdentity(snapshot);
    this.policy(snapshot.excludedPaths);
    const files = await this.scan(), remoteFiles = snapshot.files.filter((file) => !file.heads.some((head) => this.isExcluded(head.path)));
    const result = { upload: 0, download: 0, same: 0, conflicts: 0, local: files.size, remote: remoteFiles.length };
    const matched = /* @__PURE__ */ new Set();
    for (const file of remoteFiles) {
      if (file.heads.length !== 1) {
        result.conflicts++;
        file.heads.forEach((h) => matched.add(pathKey(h.path)));
        continue;
      }
      const head = file.heads[0], data = [...files].find(([p]) => pathKey(p) === pathKey(head.path));
      if (data) {
        matched.add(pathKey(data[0]));
        if (!head.deleted && data[0] === head.path && hash(data[1]) === head.hash) result.same++;
        else result.conflicts++;
      } else if (!head.deleted) result.download++;
    }
    for (const path of files.keys()) if (!matched.has(pathKey(path))) result.upload++;
    return result;
  }
  initialize() {
    return this.exclusive(async () => {
      if (this.state.initialized) return;
      await this.snapshot();
      const files = await this.scan();
      for (const [path, data] of files) this.bindUntracked(path, data);
      this.state.initialized = true;
      await this.save(this.state);
    });
  }
  bindUntracked(path, data) {
    const matches = Object.values(this.state.remote).filter((f) => f.heads.some((h) => pathKey(h.path) === pathKey(path)));
    if (matches.length > 1) throw new Error(`\u8FDC\u7AEF\u8DEF\u5F84\u5B58\u5728\u591A\u4E2A\u8EAB\u4EFD\uFF1A${path}`);
    const match = matches[0], fileId = match?.fileId ?? id(), head = match?.heads[0];
    if (this.state.entries[fileId]) throw new Error(`\u8FDC\u7AEF\u76EE\u6807\u8DEF\u5F84\u5DF2\u6709\u672C\u5730\u8EAB\u4EFD\uFF0C\u8BF7\u5148\u5904\u7406\u79FB\u52A8\u51B2\u7A81\uFF1A${path}`);
    const same = match?.heads.length === 1 && !head?.deleted && head?.path === path && head?.hash === hash(data);
    this.state.entries[fileId] = {
      fileId,
      path,
      basePath: path,
      baseRevision: head?.id ?? null,
      baseHash: match ? hash(data) : null,
      baseDeleted: false,
      materialized: true,
      ...match && !same ? { blocked: "\u672C\u5730\u4E0E\u8FDC\u7AEF\u540C\u540D\u4F46\u5185\u5BB9\u6216\u7248\u672C\u4E0D\u540C\uFF0C\u8BF7\u9009\u62E9\u4FDD\u7559\u7248\u672C" } : {}
    };
  }
  noteRename(oldPath, path) {
    return this.exclusive(async () => {
      for (const e of Object.values(this.state.entries)) {
        if (e.materialized && (e.path === oldPath || e.path.startsWith(oldPath + "/"))) {
          const next = path + e.path.slice(oldPath.length);
          if (!this.isExcluded(next)) validatePath(next);
          e.path = next;
        }
      }
      await this.save(this.state);
    });
  }
  approveDeletes() {
    return this.exclusive(async () => {
      this.state.deleteApproval = this.state.deletePlan?.fingerprint;
      await this.save(this.state);
    });
  }
  sync(idleCheck = false) {
    if (this.running) return this.running;
    const run = this.exclusive(() => this.work(idleCheck));
    this.running = run.finally(() => {
      this.running = void 0;
    });
    return this.running;
  }
  async pull() {
    if (!this.state.epoch) return this.snapshot();
    for (; ; ) {
      try {
        const page = await this.remote.changes(this.state.cursor, this.state.epoch);
        this.checkIdentity(page);
        if (page.epoch !== this.state.epoch) throw new SyncError("resync_required", "\u670D\u52A1\u7AEF\u4EE3\u6B21\u53D8\u5316");
        if (page.more && page.cursor === this.state.cursor) throw new Error("\u8FDC\u7AEF\u5206\u9875\u6E38\u6807\u672A\u524D\u8FDB\uFF0C\u5DF2\u505C\u6B62\u62C9\u53D6");
        this.policy(page.excludedPaths);
        for (const event of page.changes) this.state.remote[event.file.fileId] = event.file;
        this.state.cursor = page.cursor;
        await this.save(this.state);
        if (!page.more) break;
      } catch (e) {
        if (e instanceof SyncError && e.code === "resync_required") {
          await this.snapshot();
          break;
        }
        throw e;
      }
    }
  }
  makePending(e, content) {
    return {
      revision: {
        id: id(),
        fileId: e.fileId,
        parents: e.baseRevision ? [e.baseRevision] : [],
        path: e.path,
        deleted: content === null,
        hash: content === null ? null : hash(content),
        size: content?.length ?? 0,
        clientId: this.state.clientId
      },
      content: content === null ? null : content.toString("base64")
    };
  }
  async stage() {
    const files = await this.scan();
    const tracked = new Set(Object.values(this.state.entries).map((e) => pathKey(e.path)));
    for (const [path, data] of files) if (!tracked.has(pathKey(path))) this.bindUntracked(path, data);
    const deletions = [];
    for (const e of Object.values(this.state.entries)) {
      if (this.isExcluded(e.path)) continue;
      if (e.blocked && !e.materialized && !files.has(e.path)) delete e.blocked;
      if (e.blocked) {
        this.state.issues[e.fileId] = e.blocked;
        continue;
      }
      if (this.state.pending.some((p) => p.revision.fileId === e.fileId)) continue;
      const remote = this.state.remote[e.fileId];
      if (remote && remote.heads.length > 1) {
        this.state.issues[e.fileId] = "\u591A\u53F0\u8BBE\u5907\u4FEE\u6539\u4E86\u540C\u4E00\u7BC7\u7B14\u8BB0\uFF0C\u8BF7\u5904\u7406\u51B2\u7A81";
        continue;
      }
      if (e.baseRevision && !remote) {
        this.state.issues[e.fileId] = "\u670D\u52A1\u5668\u7F3A\u5C11\u5DF2\u77E5\u6587\u4EF6\u5386\u53F2\uFF0C\u5DF2\u6682\u505C\u6B64\u6587\u4EF6";
        continue;
      }
      const data = files.get(e.path);
      if (data && !e.materialized) {
        e.blocked = "\u4E0B\u8F7D\u524D\u672C\u5730\u51FA\u73B0\u540C\u540D\u6587\u4EF6\uFF0C\u8BF7\u9009\u62E9\u4FDD\u7559\u7248\u672C";
        this.state.issues[e.fileId] = e.blocked;
        continue;
      }
      if (data) {
        if (data.length > MAX_BYTES) throw new Error(`\u7B14\u8BB0\u8D85\u8FC7 5 MiB\uFF1A${e.path}`);
        if (!e.baseRevision || e.baseDeleted || hash(data) !== e.baseHash || e.path !== e.basePath) this.state.pending.push(this.makePending(e, data));
      } else if (e.materialized && !e.baseDeleted && e.baseRevision) deletions.push(this.makePending(e, null));
    }
    const count = Object.values(this.state.entries).filter((e) => !e.baseDeleted && !this.isExcluded(e.path)).length;
    const protectedBatch = deletions.length >= 10 && deletions.length / Math.max(count, 1) >= 0.1 || deletions.length >= 5 && deletions.length / Math.max(count, 1) >= 0.2;
    const fingerprint = hash(JSON.stringify(deletions.map((p) => [p.revision.fileId, p.revision.parents, p.revision.path]).sort()));
    if (protectedBatch && this.state.deleteApproval !== fingerprint) {
      this.state.deletePlan = { fingerprint, paths: deletions.map((p) => p.revision.path), direction: "local" };
      this.state.issues.__deletes__ = `\u6279\u91CF\u5220\u9664\u4FDD\u62A4\uFF1A${deletions.length} \u7BC7\uFF0C\u7B49\u5F85\u786E\u8BA4`;
    } else {
      this.state.pending.push(...deletions);
      if (this.state.deletePlan?.direction === "local") {
        delete this.state.deletePlan;
        delete this.state.deleteApproval;
      }
    }
    await this.save(this.state);
  }
  acknowledge(revision) {
    const e = this.state.entries[revision.fileId];
    e.baseRevision = revision.id;
    e.basePath = revision.path;
    e.baseHash = revision.hash;
    e.baseDeleted = revision.deleted;
    e.materialized = true;
    delete e.blocked;
  }
  async flush() {
    for (const pending of [...this.state.pending]) {
      if (this.stopped) return;
      if (this.isExcluded(pending.revision.path) || this.isExcluded(this.state.entries[pending.revision.fileId]?.path ?? pending.revision.path)) continue;
      try {
        if (pending.content !== null) {
          const data = Buffer.from(pending.content, "base64");
          if (hash(data) !== pending.revision.hash) throw new Error("\u672C\u5730\u5F85\u4E0A\u4F20\u5FEB\u7167\u635F\u574F\uFF0C\u505C\u6B62\u63D0\u4EA4");
          await this.remote.put(data, pending.revision.hash);
        }
        await this.remote.commit(pending.revision);
        if (!pending.applyAfter) this.acknowledge(pending.revision);
        this.state.pending = this.state.pending.filter((p) => p.revision.id !== pending.revision.id);
        await this.save(this.state);
      } catch (e) {
        if (e instanceof SyncError && ["path_conflict", "unknown_parent", "missing_parent", "idempotency_conflict"].includes(e.code)) {
          this.state.issues[pending.revision.fileId] = e.message;
          await this.save(this.state);
          continue;
        }
        throw e;
      }
    }
  }
  async recoverApply() {
    const job = this.state.applying;
    if (!job) return;
    const e = this.state.entries[job.fileId], r = job.revision;
    const target = await this.local.read(r.path);
    const old = e.path === r.path ? target : await this.local.read(e.path);
    if (r.deleted ? !old : !!target && hash(target) === r.hash && (e.path === r.path || !old)) {
      this.acknowledge(r);
      e.path = r.path;
    }
    delete this.state.applying;
    await this.save(this.state);
  }
  async applyRemote() {
    const deletions = Object.values(this.state.remote).filter((f) => f.heads.length === 1 && !this.isExcluded(f.heads[0].path) && !this.isExcluded(this.state.entries[f.fileId]?.path ?? f.heads[0].path) && f.heads[0].deleted && this.state.entries[f.fileId]?.materialized && !this.state.entries[f.fileId].baseDeleted && this.state.entries[f.fileId].baseRevision !== f.heads[0].id);
    const live = Object.values(this.state.entries).filter((e) => !e.baseDeleted && !this.isExcluded(e.path)).length;
    const fingerprint = hash("remote:" + JSON.stringify(deletions.map((f) => f.heads[0].id).sort()));
    const blockDeletes = (deletions.length >= 10 && deletions.length / Math.max(live, 1) >= 0.1 || deletions.length >= 5 && deletions.length / Math.max(live, 1) >= 0.2) && this.state.deleteApproval !== fingerprint;
    if (blockDeletes) {
      this.state.deletePlan = { fingerprint, paths: deletions.map((f) => f.heads[0].path), direction: "remote" };
      this.state.issues.__deletes__ = `\u8FDC\u7AEF\u6279\u91CF\u5220\u9664\u4FDD\u62A4\uFF1A${deletions.length} \u7BC7\uFF0C\u7B49\u5F85\u786E\u8BA4`;
    }
    for (const file of Object.values(this.state.remote)) {
      if (this.stopped) return;
      let e = this.state.entries[file.fileId];
      if (e && this.isExcluded(e.path) || file.heads.some((head) => this.isExcluded(head.path))) continue;
      if (file.heads.length !== 1) {
        this.state.issues[file.fileId] = "\u5B58\u5728\u591A\u4E2A\u7248\u672C\uFF0C\u8BF7\u67E5\u770B\u51B2\u7A81";
        continue;
      }
      const r = file.heads[0];
      if (blockDeletes && r.deleted) continue;
      if (!e && r.deleted) continue;
      if (!e) {
        e = { fileId: file.fileId, path: r.path, basePath: r.path, baseRevision: null, baseHash: null, baseDeleted: true, materialized: false };
        this.state.entries[e.fileId] = e;
      }
      if (e.blocked || this.state.pending.some((p) => p.revision.fileId === e.fileId)) continue;
      if (e.baseRevision === r.id) continue;
      const content = r.deleted ? null : await this.remote.get(r.hash);
      this.state.applying = { fileId: e.fileId, revision: r };
      await this.save(this.state);
      try {
        const current = await this.local.read(e.path);
        if (!(e.path === r.path && (content === null ? current === null : current !== null && hash(current) === r.hash))) {
          await this.local.apply({ oldPath: e.path, path: r.path, expectedHash: e.materialized && !e.baseDeleted ? e.baseHash : null, content });
        }
        this.acknowledge(r);
        e.path = r.path;
      } catch (error) {
        this.state.issues[e.fileId] = error instanceof Error ? error.message : "\u672C\u5730\u6587\u4EF6\u53D8\u5316\uFF0C\u7B49\u5F85\u5904\u7406";
      } finally {
        delete this.state.applying;
        await this.save(this.state);
      }
    }
    if (!blockDeletes && this.state.deletePlan?.direction === "remote") {
      delete this.state.deletePlan;
      delete this.state.deleteApproval;
    }
  }
  async work(idleCheck) {
    if (this.stopped || !this.state.initialized) return;
    if (this.state.overwrite) throw new Error("\u8986\u76D6\u5C1A\u672A\u5B8C\u6210\uFF0C\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u7EE7\u7EED\u6216\u91CD\u65B0\u9884\u89C8");
    await this.remote.verifyProtocol();
    if (idleCheck && !this.state.applying && !this.state.pending.length && !Object.keys(this.state.issues).length && !this.state.deletePlan) {
      const before = JSON.stringify([this.state.epoch, this.state.cursor, this.state.serverExcludedPaths]);
      await this.pull();
      if (before === JSON.stringify([this.state.epoch, this.state.cursor, this.state.serverExcludedPaths])) {
        this.report("\u5DF2\u540C\u6B65");
        return;
      }
    }
    this.report("\u6B63\u5728\u540C\u6B65\u2026");
    this.state.issues = {};
    await this.recoverApply();
    await this.pull();
    await this.stage();
    await this.flush();
    await this.pull();
    await this.applyRemote();
    await this.stage();
    await this.save(this.state);
    const count = Object.keys(this.state.issues).length;
    const held = this.state.pending.filter((p) => this.isExcluded(p.revision.path) || this.isExcluded(this.state.entries[p.revision.fileId]?.path ?? p.revision.path)).length;
    const uploading = this.state.pending.length - held;
    this.report(count ? `${count} \u9879\u9700\u5904\u7406` : uploading ? `\u5F85\u4E0A\u4F20 ${uploading} \u9879` : held ? `\u5DF2\u540C\u6B65\uFF0C${held} \u9879\u5DF2\u6392\u9664\u5E76\u4FDD\u7559\u5F85\u4E0A\u4F20\u5FEB\u7167` : "\u5DF2\u540C\u6B65");
  }
  retryRenamed(fileId) {
    return this.exclusive(async () => {
      await this.pull();
      const e = this.state.entries[fileId];
      const pending = this.state.pending.filter((p) => p.revision.fileId === fileId);
      if (!e || this.state.remote[fileId] || !pending.length || pending.some((p) => p.revision.path === e.path)) throw new Error("\u8BF7\u5148\u5C06\u51B2\u7A81\u7684\u65B0\u6587\u4EF6\u6539\u4E3A\u672A\u5360\u7528\u7684\u540D\u79F0");
      for (const p of pending) if (p.content !== null) await this.local.preserve(Buffer.from(p.content, "base64"));
      this.state.pending = this.state.pending.filter((p) => p.revision.fileId !== fileId);
      e.baseRevision = null;
      e.baseHash = null;
      delete e.blocked;
      await this.save(this.state);
    });
  }
  resolve(fileId, choice) {
    return this.exclusive(async () => {
      await this.remote.verifyProtocol();
      await this.pull();
      const e = this.state.entries[fileId], file = this.state.remote[fileId];
      if (!e || !file || !file.heads.length) throw new Error("\u65E0\u6CD5\u627E\u5230\u6587\u4EF6\u7248\u672C");
      if (this.isExcluded(e.path) || file.heads.some((head) => this.isExcluded(head.path)) || choice !== "local" && this.isExcluded(choice.path)) throw new Error("\u8BE5\u6587\u4EF6\u5728\u6392\u9664\u89C4\u5219\u5185\uFF0C\u8BF7\u5148\u8C03\u6574\u89C4\u5219\u518D\u9009\u62E9\u7248\u672C");
      const local = await this.local.read(e.path);
      if (local) await this.local.preserve(local);
      for (const p of this.state.pending.filter((p2) => p2.revision.fileId === fileId)) if (p.content !== null) await this.local.preserve(Buffer.from(p.content, "base64"));
      const selected = choice === "local" ? null : choice;
      if (selected && selected.fileId !== fileId) throw new Error("\u5386\u53F2\u7248\u672C\u8EAB\u4EFD\u4E0D\u5339\u914D");
      const content = choice === "local" ? local : selected.deleted ? null : await this.remote.get(selected.hash);
      const revision = {
        id: id(),
        fileId,
        parents: file.heads.map((h) => h.id).sort(),
        path: selected?.path ?? e.path,
        deleted: content === null,
        hash: content === null ? null : hash(content),
        size: content?.length ?? 0,
        clientId: this.state.clientId
      };
      if (content !== null) await this.remote.put(content, revision.hash);
      this.state.pending = this.state.pending.filter((p) => p.revision.fileId !== fileId);
      this.state.pending.push({ revision, content: content === null ? null : content.toString("base64"), applyAfter: true });
      delete e.blocked;
      e.baseHash = local ? hash(local) : null;
      e.baseDeleted = local === null;
      e.materialized = true;
      await this.save(this.state);
      await this.flush();
      await this.pull();
      await this.applyRemote();
      await this.save(this.state);
    });
  }
};

// src/sync/obsidian-vault.ts
var import_obsidian2 = require("obsidian");
var import_node_fs2 = require("node:fs");
var import_node_path2 = require("node:path");
var ObsidianVault = class {
  constructor(app, disk) {
    this.app = app;
    this.disk = disk;
    this.applying = false;
    if (!(app.vault.adapter instanceof import_obsidian2.FileSystemAdapter)) throw new Error("\u9996\u7248\u4EC5\u652F\u6301\u684C\u9762\u6587\u4EF6\u7CFB\u7EDF Vault");
    this.root = (0, import_node_fs2.realpathSync)(app.vault.adapter.getBasePath());
  }
  safe(path) {
    validatePath(path);
    const target = (0, import_node_path2.resolve)(this.root, path);
    const rel = (0, import_node_path2.relative)(this.root, target);
    if (!rel || rel.startsWith(".." + import_node_path2.sep) || rel === ".." || (0, import_node_path2.resolve)(this.root, rel) !== target) throw new Error("\u8DEF\u5F84\u8D8A\u51FA Vault");
    let current = this.root;
    for (const part of path.split("/")) {
      current = (0, import_node_path2.join)(current, part);
      if ((0, import_node_fs2.existsSync)(current) && (0, import_node_fs2.lstatSync)(current).isSymbolicLink()) throw new Error(`\u4E0D\u652F\u6301\u7B26\u53F7\u94FE\u63A5\uFF1A${path}`);
    }
  }
  async scan(accept) {
    const result = /* @__PURE__ */ new Map(), keys = /* @__PURE__ */ new Set();
    let total = 0;
    const files = this.app.vault.getMarkdownFiles();
    if (files.length > MAX_FILES) throw new Error("\u9996\u7248\u6700\u591A\u652F\u6301 10000 \u4E2A Markdown \u6587\u4EF6");
    for (const file of files) {
      if (isExcluded(file.path, [], this.app.vault.configDir) || accept && !accept(file.path)) continue;
      this.safe(file.path);
      if (keys.has(pathKey(file.path))) throw new Error(`\u6587\u4EF6\u8DEF\u5F84\u5927\u5C0F\u5199\u51B2\u7A81\uFF1A${file.path}`);
      keys.add(pathKey(file.path));
      if (file.stat.size > MAX_BYTES) throw new Error(`\u7B14\u8BB0\u8D85\u8FC7 5 MiB\uFF1A${file.path}`);
      const data = Buffer.from(await this.app.vault.readBinary(file));
      total += data.length;
      if (total > 128 * 1024 * 1024) throw new Error("\u9996\u7248\u6BCF\u4E2A Vault \u7684 Markdown \u6B63\u6587\u5408\u8BA1\u6700\u591A 128 MiB");
      if (data.length > MAX_BYTES || !Buffer.from(data.toString("utf8")).equals(data)) throw new Error(`\u6B63\u6587\u8D85\u9650\u6216\u4E0D\u662F\u6709\u6548 UTF-8\uFF1A${file.path}`);
      result.set(file.path, data);
    }
    return result;
  }
  async read(path) {
    this.safe(path);
    const file = this.app.vault.getAbstractFileByPath(path);
    if (file instanceof import_obsidian2.TFile) return Buffer.from(await this.app.vault.readBinary(file));
    if ((0, import_node_fs2.existsSync)((0, import_node_path2.join)(this.root, path))) throw new Error(`\u8DEF\u5F84\u5DF2\u5B58\u5728\u4F46\u5C1A\u672A\u88AB Obsidian \u8BC6\u522B\uFF1A${path}`);
    return null;
  }
  preserve(data) {
    return this.disk.preserve(data);
  }
  ensureClosed(path) {
    if (this.app.workspace.getLeavesOfType("markdown").some((l) => l.view instanceof import_obsidian2.MarkdownView && l.view.file?.path === path)) {
      throw new Error(`\u7B14\u8BB0\u6B63\u5728\u7F16\u8F91\u5668\u4E2D\u6253\u5F00\uFF0C\u8BF7\u5173\u95ED\u540E\u540C\u6B65\uFF1A${path}`);
    }
  }
  assertClosed(paths) {
    for (const path of paths) this.ensureClosed(path);
  }
  async folders(path) {
    const parts = path.split("/");
    parts.pop();
    let current = "";
    for (const part of parts) {
      current = current ? current + "/" + part : part;
      if (!this.app.vault.getAbstractFileByPath(current)) await this.app.vault.createFolder(current);
    }
  }
  async apply(r) {
    this.safe(r.oldPath);
    this.safe(r.path);
    this.ensureClosed(r.oldPath);
    this.ensureClosed(r.path);
    const current = await this.read(r.oldPath);
    if ((current ? hash(current) : null) !== r.expectedHash) throw new Error(`\u4E0B\u8F7D\u671F\u95F4\u672C\u5730\u53D1\u751F\u53D8\u5316\uFF0C\u8BF7\u67E5\u770B\u7248\u672C\uFF1A${r.oldPath}`);
    if (r.path !== r.oldPath && await this.read(r.path)) throw new Error(`\u79FB\u52A8\u76EE\u6807\u5DF2\u5B58\u5728\uFF1A${r.path}`);
    if (current) await this.preserve(current);
    if (r.content && !Buffer.from(r.content.toString("utf8")).equals(r.content)) throw new Error("\u8FDC\u7AEF\u5185\u5BB9\u4E0D\u662F\u6709\u6548 UTF-8");
    this.applying = true;
    try {
      if (r.content === null) {
        const file = this.app.vault.getAbstractFileByPath(r.oldPath);
        if (file instanceof import_obsidian2.TFile) {
          this.ensureClosed(r.oldPath);
          if (hash(Buffer.from(await this.app.vault.readBinary(file))) !== r.expectedHash) throw new Error("\u5220\u9664\u524D\u672C\u5730\u6587\u4EF6\u53D1\u751F\u53D8\u5316");
          await this.app.fileManager.trashFile(file);
        }
      } else if (current && r.path === r.oldPath) {
        const file = this.app.vault.getAbstractFileByPath(r.path);
        if (!(file instanceof import_obsidian2.TFile)) throw new Error("\u672C\u5730\u6587\u4EF6\u4E0D\u518D\u5B58\u5728");
        this.ensureClosed(r.path);
        await this.app.vault.process(file, (text) => {
          this.ensureClosed(r.path);
          if (hash(Buffer.from(text, "utf8")) !== r.expectedHash) throw new Error("\u672C\u5730\u5185\u5BB9\u6216 BOM/\u6362\u884C\u8BED\u4E49\u4E0D\u540C\uFF0C\u505C\u6B62\u81EA\u52A8\u8986\u76D6");
          return r.content.toString("utf8");
        });
      } else {
        await this.folders(r.path);
        this.safe(r.path);
        this.ensureClosed(r.path);
        await this.app.vault.createBinary(r.path, Uint8Array.from(r.content).buffer);
        if (current && r.path !== r.oldPath) {
          const old = this.app.vault.getAbstractFileByPath(r.oldPath);
          this.ensureClosed(r.oldPath);
          if (!(old instanceof import_obsidian2.TFile) || hash(Buffer.from(await this.app.vault.readBinary(old))) !== r.expectedHash) throw new Error("\u79FB\u52A8\u4E2D\u539F\u6587\u4EF6\u53D8\u5316\uFF0C\u5DF2\u4FDD\u7559\u53CC\u65B9");
          await this.app.fileManager.trashFile(old);
        }
      }
      const actual = await this.read(r.path);
      if (r.content !== null && (!actual || hash(actual) !== hash(r.content))) {
        await this.preserve(r.content);
        throw new Error("\u843D\u76D8\u5B57\u8282\u6821\u9A8C\u5931\u8D25\uFF0C\u53CC\u65B9\u5185\u5BB9\u5DF2\u4FDD\u7559\uFF0C\u6682\u505C\u6B64\u6587\u4EF6");
      }
    } finally {
      this.applying = false;
    }
  }
};

// src/sync/remote.ts
function normalizeServer(value, allowHttp = false) {
  const u = new URL(value);
  if (u.username || u.password || u.search || u.hash || u.pathname !== "/") throw new Error("\u8BF7\u586B\u5199\u670D\u52A1\u6839\u5730\u5740\uFF0C\u4F8B\u5982 https://notes.example.com");
  if (u.protocol !== "https:" && !(u.protocol === "http:" && (allowHttp || ["localhost", "127.0.0.1", "[::1]"].includes(u.hostname)))) throw new Error("\u8FDC\u7A0B\u670D\u52A1\u9700\u8981 HTTPS\uFF1B\u6D4B\u8BD5\u5185\u7F51 HTTP \u9700\u663E\u5F0F\u5F00\u542F");
  return u.origin;
}
var Remote = class _Remote {
  constructor(url, vaultId, token, transport) {
    this.url = url;
    this.vaultId = vaultId;
    this.token = token;
    this.transport = transport;
  }
  async request(path, method = "GET", body, binary = false) {
    const response = await this.transport(this.url + path, method, {
      Authorization: "Bearer " + this.token,
      ...body ? { "Content-Type": binary ? "application/octet-stream" : "application/json" } : {}
    }, body);
    if (response.status < 200 || response.status >= 300) {
      let value;
      try {
        value = JSON.parse(response.body.toString("utf8"));
      } catch {
      }
      throw new SyncError(typeof value?.code === "string" ? value.code : "http_error", typeof value?.message === "string" ? value.message.slice(0, 200) : `\u670D\u52A1\u5668\u8FD4\u56DE HTTP ${response.status}`, response.status);
    }
    return response.body;
  }
  path(tail) {
    return `/v1/vaults/${this.vaultId}/${tail}`;
  }
  async verifyProtocol() {
    let health;
    try {
      health = JSON.parse((await this.request("/v1/health")).toString("utf8"));
    } catch (error) {
      if (error instanceof SyntaxError) throw new Error("\u670D\u52A1\u7AEF\u534F\u8BAE\u54CD\u5E94\u65E0\u6548\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458");
      throw error;
    }
    if (!health?.ok || health.protocol !== PROTOCOL) throw new Error("\u5BA2\u6237\u7AEF\u4E0E\u670D\u52A1\u7AEF\u7248\u672C\u4E0D\u517C\u5BB9\uFF0C\u8BF7\u5411\u7BA1\u7406\u5458\u83B7\u53D6\u5339\u914D\u7248\u672C");
  }
  async snapshot() {
    const s = JSON.parse((await this.request(this.path("state"))).toString("utf8"));
    if (s.protocol !== PROTOCOL || !Array.isArray(s.files) || !validCursor(s.cursor) || typeof s.epoch !== "string" || typeof s.serverId !== "string") throw new Error("\u670D\u52A1\u7AEF\u534F\u8BAE\u6216\u5FEB\u7167\u65E0\u6548");
    if (s.excludedPaths !== void 0) s.excludedPaths = normalizeExclusions(s.excludedPaths);
    for (const file of s.files) {
      if (!file.heads.length) throw new Error("\u8FDC\u7AEF\u6587\u4EF6\u7F3A\u5C11\u7248\u672C");
      file.heads = file.heads.map(validateRevision);
      if (file.heads.some((r) => r.fileId !== file.fileId)) throw new Error("\u8FDC\u7AEF\u6587\u4EF6\u8EAB\u4EFD\u65E0\u6548");
    }
    return s;
  }
  async changes(cursor, epoch) {
    const c = JSON.parse((await this.request(this.path(`changes?after=${encodeURIComponent(cursor)}&epoch=${encodeURIComponent(epoch)}`))).toString("utf8"));
    if (!Array.isArray(c.changes) || !validCursor(c.cursor)) throw new Error("\u8FDC\u7AEF\u6E38\u6807\u65E0\u6548");
    if (c.excludedPaths !== void 0) c.excludedPaths = normalizeExclusions(c.excludedPaths);
    for (const event of c.changes) {
      if (!validCursor(event.seq) || !event.file.heads.length || typeof cursor === "number" && typeof event.seq === "number" && event.seq <= cursor) throw new Error("\u8FDC\u7AEF\u4E8B\u4EF6\u65E0\u6548");
      event.file.heads = event.file.heads.map(validateRevision);
      if (event.file.heads.some((r) => r.fileId !== event.file.fileId)) throw new Error("\u8FDC\u7AEF\u4E8B\u4EF6\u8EAB\u4EFD\u65E0\u6548");
    }
    return c;
  }
  async put(data, sha) {
    await this.request(this.path("objects/" + sha), "PUT", data, true);
  }
  async get(sha) {
    const data = await this.request(this.path("objects/" + sha));
    if (data.length > MAX_BYTES || hash(data) !== sha) throw new Error("\u4E0B\u8F7D\u5185\u5BB9\u6821\u9A8C\u5931\u8D25");
    return data;
  }
  async commit(revision) {
    const r = JSON.parse((await this.request(this.path("commits"), "POST", Buffer.from(JSON.stringify(revision)))).toString("utf8"));
    if (JSON.stringify(validateRevision(r.revision)) !== JSON.stringify(validateRevision(revision))) throw new Error("\u63D0\u4EA4\u56DE\u6267\u4E0E\u672C\u5730\u4FEE\u8BA2\u4E0D\u4E00\u81F4");
    return r;
  }
  async commitStrict(revision, expectedHeads) {
    const r = JSON.parse((await this.request(this.path("reconcile"), "POST", Buffer.from(JSON.stringify({ revision, expectedHeads })))).toString("utf8"));
    if (JSON.stringify(validateRevision(r.revision)) !== JSON.stringify(validateRevision(revision))) throw new Error("\u63D0\u4EA4\u56DE\u6267\u4E0E\u672C\u5730\u4FEE\u8BA2\u4E0D\u4E00\u81F4");
    return r;
  }
  async history(fileId, before) {
    const value = JSON.parse((await this.request(this.path("history/" + fileId + (before !== void 0 ? "?before=" + encodeURIComponent(before) : "")))).toString("utf8"));
    return value.revisions.map((r) => ({ seq: r.seq, revision: validateRevision(r.revision) }));
  }
  async known(ids) {
    const result = /* @__PURE__ */ new Set();
    for (let offset = 0; offset < ids.length; offset += 100) {
      const page = JSON.parse((await this.request(this.path("check"), "POST", Buffer.from(JSON.stringify({ revisions: ids.slice(offset, offset + 100) })))).toString("utf8"));
      if (!Array.isArray(page.known) || page.known.some((v) => typeof v !== "string" || !ids.includes(v))) throw new Error("\u7248\u672C\u6838\u5BF9\u54CD\u5E94\u65E0\u6548");
      for (const value of page.known) result.add(value);
    }
    return result;
  }
  static async pair(url, code, name, transport, requestId = id()) {
    const remote = new _Remote(url, "", "", transport);
    return JSON.parse((await remote.request("/v1/pair", "POST", Buffer.from(JSON.stringify({ code, deviceName: name, requestId })))).toString("utf8"));
  }
};

// shared/connection.ts
function connectionUrl(value) {
  const u = new URL(value.trim());
  if (!["https:", "http:"].includes(u.protocol) || u.username || u.password || u.search || u.hash || u.pathname !== "/") throw new Error("\u8FDE\u63A5\u5730\u5740\u65E0\u6548\uFF0C\u8BF7\u4ECE\u7BA1\u7406\u5458\u63D0\u4F9B\u7684\u5B8C\u6574\u8FDE\u63A5\u7801\u5BFC\u5165");
  return u.origin;
}
function decodeConnection(value) {
  let raw = value.trim();
  if (raw.startsWith("obsidian://lan-note-sync?")) raw = new URL(raw).searchParams.get("connection") ?? "";
  if (!raw.startsWith("lansync:") || raw.length > 4096) throw new Error("\u8BF7\u7C98\u8D34\u7BA1\u7406\u5458\u63D0\u4F9B\u7684\u5B8C\u6574\u8FDE\u63A5\u7801\uFF08\u4EE5 lansync: \u5F00\u5934\uFF09");
  try {
    const c = JSON.parse(Buffer.from(raw.slice(8), "base64url").toString("utf8"));
    if (c.protocol !== PROTOCOL || typeof c.code !== "string" || !/^[a-f0-9]{24}$/.test(c.code)) throw new Error();
    return { protocol: PROTOCOL, server: connectionUrl(c.server), code: c.code };
  } catch {
    throw new Error("\u8FDE\u63A5\u7801\u65E0\u6548\u6216\u7248\u672C\u4E0D\u517C\u5BB9\uFF0C\u8BF7\u5411\u7BA1\u7406\u5458\u91CD\u65B0\u83B7\u53D6");
  }
}

// src/sync/enrollment.ts
var import_node_fs3 = require("node:fs");
var import_node_path3 = require("node:path");
var Enrollment = class {
  constructor(folder) {
    this.folder = folder;
  }
  read(name) {
    const file = (0, import_node_path3.join)(this.folder, name);
    if (!(0, import_node_fs3.existsSync)(file)) return null;
    const bytes = (0, import_node_fs3.readFileSync)(file);
    if (bytes.length > 8192) throw new Error("\u5B89\u88C5\u8FDE\u63A5\u4FE1\u606F\u8FC7\u5927\uFF0C\u8BF7\u91CD\u65B0\u83B7\u53D6\u5B89\u88C5\u547D\u4EE4");
    return JSON.parse(bytes.toString("utf8").replace(/^\ufeff/, ""));
  }
  bootstrap() {
    const value = this.read("bootstrap.json");
    if (!value) return null;
    if (value.schema !== 1 || typeof value.connection !== "string") throw new Error("\u5B89\u88C5\u8FDE\u63A5\u4FE1\u606F\u65E0\u6548\uFF0C\u8BF7\u91CD\u65B0\u83B7\u53D6\u5B89\u88C5\u547D\u4EE4");
    decodeConnection(value.connection);
    return value.connection;
  }
  claim(server, code) {
    const previous = this.read("pair-claim.json");
    if (previous?.server === server && previous?.code === code && typeof previous.requestId === "string") return previous.requestId;
    const requestId = id();
    (0, import_node_fs3.mkdirSync)(this.folder, { recursive: true });
    (0, import_node_fs3.writeFileSync)((0, import_node_path3.join)(this.folder, "pair-claim.json"), JSON.stringify({ server, code, requestId }), { mode: 384 });
    return requestId;
  }
  complete() {
    for (const name of ["bootstrap.json", "pair-claim.json"]) {
      const file = (0, import_node_path3.join)(this.folder, name);
      if ((0, import_node_fs3.existsSync)(file)) (0, import_node_fs3.unlinkSync)(file);
    }
  }
};

// src/sync/async-flow.ts
var SingleFlight = class {
  get busy() {
    return this.active !== void 0;
  }
  run(key, operation) {
    if (this.active) return this.active.key === key ? this.active.promise : Promise.reject(new Error("\u53E6\u4E00\u4E2A\u8FDE\u63A5\u6B63\u5728\u5904\u7406\u4E2D\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u540E\u91CD\u8BD5"));
    const promise = Promise.resolve().then(operation).finally(() => {
      if (this.active?.promise === promise) this.active = void 0;
    });
    this.active = { key, promise };
    return promise;
  }
};
var DeadlineError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "DeadlineError";
  }
};
function withDeadline(operation, timeoutMs, message) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new DeadlineError(message)), timeoutMs);
  });
  return Promise.race([operation, timeout]).finally(() => clearTimeout(timer));
}

// src/sync/updater.ts
var import_node_fs4 = require("node:fs");
var import_node_path4 = require("node:path");
var names = ["main.js", "styles.css", "manifest.json"];
function version(value) {
  if (typeof value !== "string" || !/^\d{1,5}\.\d{1,5}\.\d{1,5}$/.test(value)) return null;
  return value.split(".").map(Number);
}
function newer(a, b) {
  for (let i = 0; i < 3; i++) {
    if (a[i] !== b[i]) return a[i] > b[i];
  }
  return false;
}
function noLink(path) {
  if ((0, import_node_fs4.existsSync)(path) && (0, import_node_fs4.lstatSync)(path).isSymbolicLink()) throw new Error("\u63D2\u4EF6\u76EE\u5F55\u542B\u6709\u94FE\u63A5\uFF0C\u81EA\u52A8\u66F4\u65B0\u5DF2\u505C\u6B62");
}
function atomicWrite(path, data) {
  const tmp = path + ".lan-update-" + id();
  try {
    const fd = (0, import_node_fs4.openSync)(tmp, "wx", 384);
    try {
      (0, import_node_fs4.writeFileSync)(fd, data);
      (0, import_node_fs4.fsyncSync)(fd);
    } finally {
      (0, import_node_fs4.closeSync)(fd);
    }
    (0, import_node_fs4.renameSync)(tmp, path);
  } finally {
    if ((0, import_node_fs4.existsSync)(tmp)) (0, import_node_fs4.unlinkSync)(tmp);
  }
}
async function updatePlugin(server, pluginDir, runningVersion, transport, compatible) {
  const loaded = version(runningVersion);
  if (!loaded) throw new Error("\u5F53\u524D\u63D2\u4EF6\u7248\u672C\u683C\u5F0F\u65E0\u6548");
  const root = (0, import_node_path4.resolve)(pluginDir), config = (0, import_node_path4.dirname)((0, import_node_path4.dirname)(root));
  if (root !== (0, import_node_path4.join)(config, "plugins", "lan-note-sync") || !root.startsWith(config + import_node_path4.sep)) throw new Error("\u63D2\u4EF6\u5B89\u88C5\u76EE\u5F55\u65E0\u6548");
  for (const p of [config, (0, import_node_path4.join)(config, "plugins"), root, ...names.map((n) => (0, import_node_path4.join)(root, n))]) noLink(p);
  const response = await transport(server + "/install/manifest", "GET", {});
  if (response.status !== 200 || response.body.length > 65536) throw new Error("\u65E0\u6CD5\u8BFB\u53D6\u63D2\u4EF6\u66F4\u65B0\u4FE1\u606F");
  let manifest;
  try {
    manifest = JSON.parse(response.body.toString("utf8"));
  } catch {
    throw new Error("\u63D2\u4EF6\u66F4\u65B0\u4FE1\u606F\u65E0\u6548");
  }
  const target = version(manifest?.version);
  if (manifest?.id !== "lan-note-sync" || !target || typeof manifest.minAppVersion !== "string" || !version(manifest.minAppVersion) || !Array.isArray(manifest.files) || manifest.files.length !== 3) throw new Error("\u63D2\u4EF6\u66F4\u65B0\u4FE1\u606F\u65E0\u6548");
  if (!compatible(manifest.minAppVersion)) throw new Error("\u65B0\u63D2\u4EF6\u9700\u8981\u66F4\u65B0 Obsidian \u540E\u624D\u80FD\u5B89\u88C5");
  let installed = loaded;
  try {
    const local = JSON.parse((0, import_node_fs4.readFileSync)((0, import_node_path4.join)(root, "manifest.json"), "utf8"));
    const disk = version(local.version);
    if (local.id === "lan-note-sync" && disk && newer(disk, installed)) installed = disk;
  } catch {
    throw new Error("\u672C\u5730\u63D2\u4EF6\u4FE1\u606F\u635F\u574F\uFF0C\u81EA\u52A8\u66F4\u65B0\u5DF2\u505C\u6B62");
  }
  if (!newer(target, installed)) return null;
  const assets = /* @__PURE__ */ new Map();
  for (const asset of manifest.files) {
    if (!names.includes(asset?.name) || assets.has(asset.name) || !/^[a-f0-9]{64}$/.test(asset.sha256) || !Number.isSafeInteger(asset.size) || asset.size < 0 || asset.size > 10 * 1024 * 1024) throw new Error("\u63D2\u4EF6\u66F4\u65B0\u6587\u4EF6\u5217\u8868\u65E0\u6548");
    const file = await transport(server + "/install/files/" + asset.name, "GET", {});
    if (file.status !== 200 || file.body.length !== asset.size || hash(file.body) !== asset.sha256) throw new Error("\u63D2\u4EF6\u66F4\u65B0\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\uFF0C\u539F\u63D2\u4EF6\u672A\u66FF\u6362");
    assets.set(asset.name, file.body);
  }
  let downloaded;
  try {
    downloaded = JSON.parse(assets.get("manifest.json").toString("utf8"));
  } catch {
    throw new Error("\u4E0B\u8F7D\u7684\u63D2\u4EF6\u4FE1\u606F\u65E0\u6548");
  }
  if (downloaded.id !== manifest.id || downloaded.version !== manifest.version || downloaded.minAppVersion !== manifest.minAppVersion) throw new Error("\u4E0B\u8F7D\u7684\u63D2\u4EF6\u4FE1\u606F\u4E0D\u4E00\u81F4");
  const backupRoot = (0, import_node_path4.join)(config, "lan-note-sync-backups");
  noLink(backupRoot);
  (0, import_node_fs4.mkdirSync)(backupRoot, { recursive: true });
  const backup = (0, import_node_path4.join)(backupRoot, "auto-" + id());
  (0, import_node_fs4.mkdirSync)(backup, { mode: 448 });
  for (const name of names) (0, import_node_fs4.copyFileSync)((0, import_node_path4.join)(root, name), (0, import_node_path4.join)(backup, name));
  try {
    for (const name of names) atomicWrite((0, import_node_path4.join)(root, name), assets.get(name));
  } catch (error) {
    for (const name of names) try {
      atomicWrite((0, import_node_path4.join)(root, name), (0, import_node_fs4.readFileSync)((0, import_node_path4.join)(backup, name)));
    } catch {
    }
    throw new Error("\u5B89\u88C5\u66F4\u65B0\u5931\u8D25\uFF0C\u65E7\u7248\u5907\u4EFD\u5DF2\u4FDD\u7559");
  }
  return manifest.version;
}

// src/sync/storage-report.ts
var import_node_fs5 = require("node:fs");
var import_node_path5 = require("node:path");
function storageWarnings(report, thresholdMiB) {
  if (!Number.isFinite(thresholdMiB) || thresholdMiB <= 0) return [];
  return Object.keys(report).filter((key) => report[key] >= thresholdMiB * 1048576);
}
function directoryBytes(path) {
  if (!(0, import_node_fs5.existsSync)(path)) return 0;
  const stat = (0, import_node_fs5.lstatSync)(path);
  if (stat.isSymbolicLink()) throw new Error("\u5BB9\u91CF\u7EDF\u8BA1\u76EE\u5F55\u5305\u542B\u94FE\u63A5\uFF0C\u5DF2\u505C\u6B62\u7EDF\u8BA1");
  if (stat.isFile()) return stat.size;
  if (!stat.isDirectory()) throw new Error("\u5BB9\u91CF\u7EDF\u8BA1\u9047\u5230\u4E0D\u652F\u6301\u7684\u6587\u4EF6\u7C7B\u578B");
  return (0, import_node_fs5.readdirSync)(path).reduce((sum, entry) => sum + directoryBytes((0, import_node_path5.join)(path, entry)), 0);
}
async function storageReport(remote, state, snapshots, trash) {
  const snapshot = await remote.snapshot();
  if (snapshot.serverId !== state.serverId) throw new Error("\u670D\u52A1\u7AEF\u8EAB\u4EFD\u5DF2\u53D8\u5316\uFF0C\u65E0\u6CD5\u7EDF\u8BA1\u5386\u53F2");
  const objects = /* @__PURE__ */ new Map();
  let seen = 0;
  for (const file of snapshot.files) {
    let before;
    for (; ; ) {
      const page = await remote.history(file.fileId, before);
      for (const item of page) {
        if (item.revision.fileId !== file.fileId) throw new Error("\u5386\u53F2\u6587\u4EF6\u8EAB\u4EFD\u4E0D\u5339\u914D");
        const r = item.revision;
        if (r.hash !== null) {
          if (objects.has(r.hash) && objects.get(r.hash) !== r.size) throw new Error("\u5386\u53F2\u5BF9\u8C61\u5927\u5C0F\u4E0D\u4E00\u81F4");
          objects.set(r.hash, r.size);
        }
      }
      seen += page.length;
      if (seen > 1e5) throw new Error("\u5386\u53F2\u8FC7\u591A\uFF0C\u7EDF\u8BA1\u5DF2\u6682\u505C\uFF1B\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458");
      if (page.length < 100) break;
      const next = page[page.length - 1].seq;
      if (next === before) throw new Error("\u5386\u53F2\u5206\u9875\u672A\u524D\u8FDB");
      before = next;
    }
  }
  let pending = 0;
  for (const item of state.pending) if (item.content !== null) {
    const data = Buffer.from(item.content, "base64");
    if (hash(data) !== item.revision.hash) throw new Error("\u5F85\u4E0A\u4F20\u5FEB\u7167\u635F\u574F\uFF0C\u65E0\u6CD5\u7EDF\u8BA1");
    pending += data.length;
  }
  return { history: [...objects.values()].reduce((a, b) => a + b, 0), snapshots: directoryBytes(snapshots), pending, trash: directoryBytes(trash) };
}
function storageGrowth(previous, current, now) {
  if (!previous || !Number.isFinite(previous.at) || now <= previous.at || !previous.report || !["history", "snapshots", "pending", "trash"].every((key) => Number.isFinite(previous.report[key]) && previous.report[key] >= 0)) return null;
  const scale = 864e5 / (now - previous.at);
  return {
    history: (current.history - previous.report.history) * scale,
    snapshots: (current.snapshots - previous.report.snapshots) * scale,
    pending: (current.pending - previous.report.pending) * scale,
    trash: (current.trash - previous.report.trash) * scale
  };
}

// src/main.ts
var LanSyncPlugin = class extends import_obsidian3.Plugin {
  constructor() {
    super(...arguments);
    this.settings = { ...DEFAULT_SETTINGS, excludedPaths: [] };
    this.status = "\u672A\u914D\u5BF9";
    this.failures = 0;
    this.nextAttempt = 0;
    this.working = false;
    this.localGeneration = 0;
    this.cleanGeneration = -1;
    this.lastFullScan = 0;
    this.disposed = false;
    this.connectionFlow = new SingleFlight();
    this.previewFlow = new SingleFlight();
    this.updateFlow = new SingleFlight();
    this.storageChecking = false;
    this.updateFailureNotified = false;
    this.workflowDialogs = /* @__PURE__ */ new Set();
    this.transport = async (url, method, headers, body) => {
      try {
        this.ensureActive();
        const response = await withDeadline((0, import_obsidian3.requestUrl)({ url, method, headers, body: body ? Uint8Array.from(body).buffer : void 0, throw: false }), 2e4, "\u540C\u6B65\u670D\u52A1\u54CD\u5E94\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\uFF1B\u672C\u5730\u7B14\u8BB0\u4E0E\u8FDE\u63A5\u4FE1\u606F\u5DF2\u4FDD\u7559");
        this.ensureActive();
        return { status: response.status, body: Buffer.from(response.arrayBuffer) };
      } catch (e) {
        if (e instanceof DeadlineError || this.disposed) throw e;
        throw new Error("\u65E0\u6CD5\u8FDE\u63A5\u540C\u6B65\u670D\u52A1\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u3001\u5730\u5740\u548C\u8BC1\u4E66\uFF1B\u672C\u5730\u4FEE\u6539\u4ECD\u4FDD\u7559");
      }
    };
  }
  get connecting() {
    return this.connectionFlow.busy;
  }
  get previewing() {
    return this.previewFlow.busy;
  }
  get unloaded() {
    return this.disposed;
  }
  async onload() {
    const raw = await this.loadData() ?? {};
    for (const key of Object.keys(DEFAULT_SETTINGS)) {
      if (key === "excludedPaths") {
        this.settings.excludedPaths = normalizeExclusions(raw.excludedPaths ?? []);
        continue;
      }
      if (typeof raw[key] === typeof DEFAULT_SETTINGS[key]) this.settings[key] = raw[key];
    }
    if (!this.settings.secretId) this.settings.secretId = "lan-sync-" + id();
    await this.saveSettings();
    this.bar = this.addStatusBarItem();
    this.bar.addClass("lan-sync-status");
    this.bar.onclick = () => void this.action(() => this.showIssues());
    this.setStatus("\u672A\u914D\u5BF9");
    this.settingsTab = new LanSettingTab(this.app, this);
    this.addSettingTab(this.settingsTab);
    this.registerObsidianProtocolHandler("lan-note-sync", (params) => {
      if (params.connection) void this.action(() => this.importConnection(params.connection));
    });
    this.addRibbonIcon("refresh-cw", "\u5C40\u57DF\u7F51\u540C\u6B65", () => void this.action(() => this.sync(true)));
    this.addCommand({ id: "sync-now", name: "\u7ACB\u5373\u540C\u6B65", callback: () => void this.action(() => this.sync(true)) });
    this.addCommand({ id: "sync-issues", name: "\u67E5\u770B\u51B2\u7A81\u4E0E\u5F85\u5904\u7406\u9879", callback: () => void this.action(() => this.showIssues()) });
    this.addCommand({ id: "sync-toggle", name: "\u6682\u505C / \u6062\u590D\u81EA\u52A8\u540C\u6B65", callback: () => void this.action(async () => {
      this.settings.enabled = !this.settings.enabled;
      await this.saveSettings();
      this.setStatus(this.settings.enabled ? "\u7B49\u5F85\u540C\u6B65" : "\u81EA\u52A8\u540C\u6B65\u5DF2\u6682\u505C");
      if (this.settings.enabled) await this.sync(true);
    }) });
    const changed = () => {
      if (!this.engine?.state.initialized || this.local?.applying || this.disposed) return;
      this.localGeneration++;
      this.setStatus(this.settings.enabled ? "\u7B49\u5F85\u540C\u6B65" : "\u672C\u5730\u5F85\u68C0\u67E5\uFF08\u81EA\u52A8\u540C\u6B65\u5DF2\u6682\u505C\uFF09");
      if (!this.settings.enabled) return;
      if (this.debounce) window.clearTimeout(this.debounce);
      this.debounce = window.setTimeout(() => {
        if (this.settings.enabled) void this.sync(false);
      }, 2e3);
    };
    this.registerEvent(this.app.vault.on("create", changed));
    this.registerEvent(this.app.vault.on("modify", changed));
    this.registerEvent(this.app.vault.on("delete", changed));
    this.registerEvent(this.app.vault.on("rename", (file, oldPath) => {
      if (this.local?.applying || !this.engine?.state.initialized) return;
      void this.engine.noteRename(oldPath, file.path).then(changed).catch(() => this.setStatus("\u8DEF\u5F84\u4E0D\u53D7\u652F\u6301\uFF0C\u8BF7\u67E5\u770B\u8BBE\u7F6E"));
    }));
    this.registerInterval(window.setInterval(() => {
      if (this.settings.enabled && Date.now() >= this.nextAttempt) void this.sync(false, true);
    }, 5e3));
    this.registerInterval(window.setInterval(() => {
      if (this.settings.autoUpdate && this.settings.vaultId) void this.checkUpdatesInBackground();
    }, 6 * 60 * 60 * 1e3));
    this.registerInterval(window.setInterval(() => {
      if (this.settings.storageLimitMiB > 0 && this.engine && this.disk && this.local) void this.checkStorage(false).catch(() => this.setStatus("\u5BB9\u91CF\u68C0\u67E5\u5931\u8D25\uFF0C\u8BF7\u6253\u5F00\u8BBE\u7F6E\u91CD\u8BD5"));
    }, 6 * 60 * 60 * 1e3));
    this.registerEvent(this.app.workspace.on("active-leaf-change", changed));
    this.app.workspace.onLayoutReady(() => {
      void this.action(async () => {
        if (!this.settings.vaultId) {
          const bootstrap = this.enrollment().bootstrap();
          if (bootstrap) {
            await this.importConnection(bootstrap);
            return;
          }
        }
        await this.setup();
        if (this.settings.enabled) await this.sync(false);
        if (this.settings.autoUpdate && this.settings.vaultId) void this.checkUpdatesInBackground();
        if (this.settings.storageLimitMiB > 0 && this.engine && this.disk && this.local) void this.checkStorage(false).catch(() => this.setStatus("\u5BB9\u91CF\u68C0\u67E5\u5931\u8D25\uFF0C\u8BF7\u6253\u5F00\u8BBE\u7F6E\u91CD\u8BD5"));
      });
    });
  }
  onunload() {
    this.disposed = true;
    for (const modal of this.workflowDialogs) modal.close();
    this.workflowDialogs.clear();
    if (this.debounce) window.clearTimeout(this.debounce);
    const disk = this.disk;
    void (this.engine?.stop() ?? Promise.resolve()).finally(() => disk?.close());
  }
  setStatus(message) {
    if (this.disposed) return;
    this.status = message;
    this.bar?.setText("\u5C40\u57DF\u7F51\u540C\u6B65\uFF1A" + message);
    this.bar?.setAttribute("aria-label", "\u5C40\u57DF\u7F51\u540C\u6B65\uFF1A" + message);
    this.settingsTab?.updateStatus(message);
  }
  ensureActive() {
    if (this.disposed) throw new Error("\u63D2\u4EF6\u5DF2\u5378\u8F7D\uFF0C\u8BF7\u91CD\u65B0\u542F\u7528\u540E\u91CD\u8BD5");
  }
  refreshSettings() {
    if (!this.disposed) this.settingsTab?.refreshBinding();
  }
  saveSettings() {
    return this.saveData(this.settings);
  }
  async checkStorage(show) {
    if (this.storageChecking) {
      if (show) throw new Error("\u5BB9\u91CF\u68C0\u67E5\u6B63\u5728\u8FDB\u884C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      return;
    }
    const engine = this.engine, disk = this.disk, local = this.local;
    if (!engine || !disk || !local) throw new Error("\u8BF7\u5148\u8FDE\u63A5\u540C\u6B65\u670D\u52A1");
    this.storageChecking = true;
    try {
      const report = await storageReport(engine.remote, engine.state, (0, import_node_path6.join)(disk.directory, "snapshots"), (0, import_node_path6.join)(local.root, ".trash"));
      this.ensureActive();
      const now = Date.now(), growth = storageGrowth(this.settings.storageSample ?? void 0, report, now);
      this.settings.storageSample = { at: now, report };
      await this.saveSettings();
      const labels = { history: "\u670D\u52A1\u7AEF\u5386\u53F2\u53CA\u5F53\u524D\u6B63\u6587\uFF08\u53BB\u91CD\u903B\u8F91\u5927\u5C0F\uFF09", snapshots: "\u672C\u673A\u6062\u590D\u5FEB\u7167", pending: "\u5F85\u4E0A\u4F20\u6B63\u6587", trash: "Vault \u5185 .trash" };
      const format = (bytes) => (bytes / 1048576).toFixed(2) + " MiB";
      const keys = Object.keys(labels);
      const warnings = storageWarnings(report, this.settings.storageLimitMiB);
      if (warnings.length) new import_obsidian3.Notice("\u5BB9\u91CF\u8D85\u8FC7\u9608\u503C\uFF1A" + warnings.map((key) => labels[key]).join("\u3001"), 1e4);
      if (show) {
        const modal = new import_obsidian3.Modal(this.app);
        modal.titleEl.setText("\u540C\u6B65\u5BB9\u91CF");
        modal.contentEl.createEl("pre", { text: keys.map((key) => `${labels[key]}\uFF1A${format(report[key])}${growth ? `\uFF1B\u53D8\u5316 ${format(growth[key])}/\u5929` : "\uFF1B\u9996\u6B21\u7EDF\u8BA1\u6682\u65E0\u589E\u957F\u901F\u5EA6"}`).join("\n") });
        modal.contentEl.createEl("p", { text: "\u5386\u53F2\u4E3A\u5DF2\u5F15\u7528\u6B63\u6587\u53BB\u91CD\u540E\u7684\u903B\u8F91\u91CF\uFF0C\u4E0D\u542B\u6570\u636E\u5E93\u7D22\u5F15\u3001\u788E\u7247\u548C\u5B64\u7ACB\u5BF9\u8C61\uFF0C\u4E0D\u80FD\u4EE3\u8868\u670D\u52A1\u5668\u5B9E\u9645\u78C1\u76D8\u5360\u7528\uFF1B\u56DE\u6536\u7AD9\u4EC5\u7EDF\u8BA1 Vault \u5185 .trash\uFF0C\u4E0D\u542B\u7CFB\u7EDF\u56DE\u6536\u7AD9\u3002\u589E\u957F\u901F\u5EA6\u662F\u4E24\u6B21\u91C7\u6837\u95F4\u5E73\u5747\u503C\u3002" });
        modal.open();
      }
    } finally {
      this.storageChecking = false;
    }
  }
  showStorage() {
    return this.checkStorage(true);
  }
  async previewSnapshotCleanup() {
    const disk = this.disk;
    if (!disk) throw new Error("\u8BF7\u5148\u8FDE\u63A5\u540C\u6B65\u670D\u52A1");
    const plan = disk.previewSnapshotCleanup(), modal = new import_obsidian3.Modal(this.app);
    modal.titleEl.setText("\u786E\u8BA4\u6E05\u7406\u672C\u673A\u6062\u590D\u5FEB\u7167");
    modal.contentEl.createEl("p", { text: `\u5C06\u6C38\u4E45\u5220\u9664 ${plan.files.length} \u4E2A\u672C\u673A\u6062\u590D\u5FEB\u7167\uFF0C\u5171 ${(plan.files.reduce((n, file) => n + file.size, 0) / 1048576).toFixed(2)} MiB\u3002\u5220\u9664\u540E\u4E0D\u80FD\u4ECE\u6B64\u76EE\u5F55\u6062\u590D\uFF1B\u8BF7\u5148\u786E\u8BA4\u5DF2\u6709\u5907\u4EFD\u3002\u4E0D\u4F1A\u6E05\u7406\u5F85\u4E0A\u4F20\u961F\u5217\u3001\u7B14\u8BB0\u3001\u56DE\u6536\u7AD9\u6216\u670D\u52A1\u7AEF\u5386\u53F2\u3002` });
    modal.contentEl.createEl("pre", { text: plan.files.map((file) => `${file.name}  ${file.size} \u5B57\u8282`).join("\n") || "\u6CA1\u6709\u53EF\u6E05\u7406\u7684\u5FEB\u7167\u3002" });
    new import_obsidian3.Setting(modal.contentEl).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => modal.close())).addButton((b) => b.setButtonText("\u786E\u8BA4\u6C38\u4E45\u5220\u9664").setWarning().setDisabled(!plan.files.length).onClick(() => {
      b.setDisabled(true);
      void this.action(async () => {
        const count = disk.cleanupSnapshots(plan.fingerprint);
        modal.close();
        new import_obsidian3.Notice(`\u5DF2\u6E05\u7406 ${count} \u4E2A\u672C\u673A\u6062\u590D\u5FEB\u7167`);
      }).finally(() => {
        if (!this.disposed) b.setDisabled(false);
      });
    }));
    modal.open();
  }
  checkUpdate(manual) {
    return this.updateFlow.run("plugin-update", async () => {
      this.ensureActive();
      if (!this.settings.vaultId) throw new Error("\u8BF7\u5148\u8FDE\u63A5\u540C\u6B65\u670D\u52A1");
      const adapter = this.app.vault.adapter;
      if (!(adapter instanceof import_obsidian3.FileSystemAdapter)) throw new Error("\u81EA\u52A8\u66F4\u65B0\u4EC5\u652F\u6301\u684C\u9762\u7AEF");
      const root = (0, import_node_path6.join)(adapter.getBasePath(), this.app.vault.configDir, "plugins", this.manifest.id);
      const result = await updatePlugin(normalizeServer(this.settings.server, this.settings.allowHttp), root, this.manifest.version, this.transport, import_obsidian3.requireApiVersion);
      this.ensureActive();
      if (result) new import_obsidian3.Notice(`\u63D2\u4EF6 ${result} \u5DF2\u4E0B\u8F7D\uFF0C\u91CD\u542F Obsidian \u540E\u751F\u6548\u3002`, 1e4);
      else if (manual) new import_obsidian3.Notice("\u63D2\u4EF6\u5DF2\u7ECF\u662F\u670D\u52A1\u7AEF\u63D0\u4F9B\u7684\u6700\u65B0\u7248\u672C\u3002");
    });
  }
  async checkUpdatesInBackground() {
    try {
      await this.checkUpdate(false);
      this.updateFailureNotified = false;
    } catch {
      if (!this.disposed && !this.updateFailureNotified) {
        this.updateFailureNotified = true;
        new import_obsidian3.Notice("\u81EA\u52A8\u66F4\u65B0\u68C0\u67E5\u5931\u8D25\uFF0C\u8BF7\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u624B\u52A8\u68C0\u67E5\u66F4\u65B0\u3002", 1e4);
      }
    }
  }
  enrollment() {
    const adapter = this.app.vault.adapter;
    if (!(adapter instanceof import_obsidian3.FileSystemAdapter)) throw new Error("\u6B64\u7248\u672C\u4EC5\u652F\u6301 Windows \u548C macOS \u684C\u9762\u7AEF");
    return new Enrollment((0, import_node_path6.join)(adapter.getBasePath(), this.app.vault.configDir, "plugins", this.manifest.id));
  }
  importConnection(value) {
    let connection;
    try {
      this.ensureActive();
      connection = decodeConnection(value);
    } catch (e) {
      return Promise.reject(e);
    }
    return this.connectionFlow.run(connection.server + "\n" + connection.code, () => this.connect(connection));
  }
  async connect(connection) {
    this.ensureActive();
    if (this.settings.vaultId) throw new Error("\u8FD9\u4E2A Vault \u5DF2\u7ECF\u8FDE\u63A5\uFF0C\u8BF7\u4F7F\u7528\u9996\u6B21\u540C\u6B65\u9884\u89C8\u6216\u7ACB\u5373\u540C\u6B65\uFF1B\u66F4\u6362\u8FDE\u63A5\u524D\u9700\u4FDD\u7559\u73B0\u6709\u57FA\u7EBF");
    const u = new URL(connection.server);
    const httpLan = u.protocol === "http:" && !["127.0.0.1", "localhost", "[::1]"].includes(u.hostname);
    if (httpLan) {
      let decide;
      const decision = new Promise((resolve4) => {
        decide = resolve4;
      });
      const modal = new import_obsidian3.Modal(this.app);
      modal.titleEl.setText("\u786E\u8BA4\u5185\u7F51\u6D4B\u8BD5\u8FDE\u63A5");
      modal.contentEl.createEl("p", { text: `\u7BA1\u7406\u5458\u63D0\u4F9B\u7684 ${u.host} \u4F7F\u7528 HTTP\uFF0C\u8FDE\u63A5\u7801\u4E0E\u7B14\u8BB0\u4F1A\u660E\u6587\u4F20\u8F93\u3002\u8BF7\u4EC5\u5728\u53EF\u4FE1\u5185\u7F51\u6D4B\u8BD5\u65F6\u7EE7\u7EED\uFF1B\u6B63\u5F0F\u4F7F\u7528\u8BF7\u5411\u7BA1\u7406\u5458\u83B7\u53D6 HTTPS \u8FDE\u63A5\u7801\u3002` });
      modal.onClose = () => decide(false);
      new import_obsidian3.Setting(modal.contentEl).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => modal.close())).addButton((b) => b.setButtonText("\u7EE7\u7EED\u5185\u7F51\u6D4B\u8BD5").onClick(() => {
        decide(true);
        modal.close();
      }));
      await this.openMainModal(modal);
      const accepted = await decision;
      this.ensureActive();
      if (!accepted) {
        this.setStatus("\u5DF2\u53D6\u6D88\u8FDE\u63A5\uFF0C\u8FDE\u63A5\u7801\u5DF2\u4FDD\u7559");
        return;
      }
    }
    this.setStatus("\u6B63\u5728\u914D\u5BF9\u2026");
    await this.pair(connection.code, connection.server, httpLan);
    this.ensureActive();
    try {
      await this.preview();
    } catch (e) {
      throw new Error("\u5DF2\u914D\u5BF9\uFF0C\u9996\u6B21\u540C\u6B65\u9884\u89C8\u672A\u5B8C\u6210\uFF1A" + (e instanceof Error ? e.message : "\u8BF7\u7A0D\u540E\u91CD\u8BD5") + "\u3002\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u91CD\u8BD5\u9884\u89C8\uFF0C\u65E0\u9700\u91CD\u65B0\u8F93\u5165\u8FDE\u63A5\u7801\u3002");
    }
  }
  async focusMainWindow() {
    this.ensureActive();
    const settings = this.app.setting;
    if (settings && typeof settings === "object" && "isOpen" in settings && settings.isOpen === true && "close" in settings && typeof settings.close === "function") settings.close();
    const mainWindow = this.app.workspace.containerEl.ownerDocument.defaultView;
    if (!mainWindow || mainWindow.closed) throw new Error("Obsidian \u4E3B\u7A97\u53E3\u4E0D\u53EF\u7528\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u7B14\u8BB0\u5E93\u540E\u91CD\u8BD5");
    for (let attempt = 0; attempt < 20; attempt++) {
      mainWindow.focus();
      await new Promise((resolve4) => window.setTimeout(resolve4, 25));
      this.ensureActive();
      if (!mainWindow.closed && activeWindow === mainWindow) return;
    }
    throw new Error("\u8BF7\u5207\u56DE Obsidian \u4E3B\u7A97\u53E3\uFF0C\u7136\u540E\u91CD\u65B0\u6253\u5F00\u8BBE\u7F6E\u91CD\u8BD5\uFF1B\u5F53\u524D\u7ED1\u5B9A\u5DF2\u4FDD\u7559");
  }
  async openMainModal(modal) {
    await this.focusMainWindow();
    this.ensureActive();
    const onClose = modal.onClose.bind(modal);
    modal.onClose = () => {
      this.workflowDialogs.delete(modal);
      onClose();
    };
    this.workflowDialogs.add(modal);
    modal.open();
  }
  async diagnose() {
    const url = normalizeServer(this.settings.server, this.settings.allowHttp);
    this.setStatus("\u6B63\u5728\u68C0\u67E5\u8FDE\u63A5\u2026");
    const result = await this.transport(url + "/v1/health", "GET", {});
    let health;
    try {
      health = JSON.parse(result.body.toString("utf8"));
    } catch {
      throw new Error("\u8FD9\u4E2A\u5730\u5740\u4E0D\u662F\u6211\u4EEC\u7684\u540C\u6B65\u670D\u52A1\uFF0C\u8BF7\u91CD\u65B0\u5BFC\u5165\u8FDE\u63A5\u7801");
    }
    if (result.status !== 200 || !health.ok) throw new Error(health?.message ?? "\u670D\u52A1\u5668\u5C1A\u672A\u5C31\u7EEA\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458");
    if (health.protocol !== PROTOCOL) throw new Error("\u5BA2\u6237\u7AEF\u4E0E\u670D\u52A1\u7AEF\u7248\u672C\u4E0D\u517C\u5BB9\uFF0C\u8BF7\u5411\u7BA1\u7406\u5458\u83B7\u53D6\u66F4\u65B0\u5305");
    this.setStatus("\u670D\u52A1\u8FDE\u63A5\u6B63\u5E38");
    new import_obsidian3.Notice("\u540C\u6B65\u670D\u52A1\u4E0E\u6570\u636E\u5E93\u8FDE\u63A5\u6B63\u5E38\u3002");
  }
  async action(fn) {
    try {
      await fn();
    } catch (e) {
      if (this.disposed) return;
      const message = e instanceof Error ? e.message : "\u64CD\u4F5C\u5931\u8D25";
      this.setStatus(message);
      new import_obsidian3.Notice(message, 8e3);
    }
  }
  async setup() {
    if (this.engine || !this.settings.vaultId) return;
    const adapter = this.app.vault.adapter;
    if (!(adapter instanceof import_obsidian3.FileSystemAdapter)) throw new Error("\u9996\u7248\u4EC5\u652F\u6301\u684C\u9762\u7AEF");
    const url = normalizeServer(this.settings.server, this.settings.allowHttp);
    const token = this.app.secretStorage.getSecret(this.settings.secretId);
    if (!token) throw new Error("\u8BBE\u5907\u51ED\u8BC1\u4E0D\u53EF\u7528\uFF0C\u8BF7\u68C0\u67E5 Obsidian \u5BC6\u94A5\u5B58\u50A8\uFF1B\u4E0D\u8981\u5220\u9664\u540C\u6B65\u57FA\u7EBF");
    this.disk = new DiskState((0, import_node_path6.join)(adapter.getBasePath(), this.app.vault.configDir, "plugins", this.manifest.id, "local-state"));
    try {
      const state = this.disk.load() ?? newState(this.settings.serverId, this.settings.vaultId, this.settings.deviceId);
      if (state.serverId !== this.settings.serverId || state.vaultId !== this.settings.vaultId || state.clientId !== this.settings.deviceId) throw new Error("\u7ED1\u5B9A\u4E0E\u672C\u5730\u57FA\u7EBF\u4E0D\u5339\u914D\uFF0C\u5DF2\u505C\u6B62\u540C\u6B65");
      this.local = new ObsidianVault(this.app, this.disk);
      this.engine = new Engine(new Remote(url, this.settings.vaultId, token, this.transport), this.local, state, (s) => this.disk.save(s), (m) => this.setStatus(m), { excludedPaths: () => this.settings.excludedPaths, configDir: this.app.vault.configDir });
      this.setStatus(state.overwrite ? "\u8986\u76D6\u5C1A\u672A\u5B8C\u6210\uFF0C\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u91CD\u65B0\u9884\u89C8" : !state.initialized ? "\u5DF2\u914D\u5BF9\uFF0C\u7B49\u5F85\u9996\u6B21\u540C\u6B65\u9884\u89C8" : this.settings.enabled ? "\u7B49\u5F85\u540C\u6B65" : "\u81EA\u52A8\u540C\u6B65\u5DF2\u6682\u505C");
    } catch (e) {
      this.disk.close();
      this.disk = void 0;
      throw e;
    }
  }
  async pair(code, server = this.settings.server, allowHttp = this.settings.allowHttp) {
    this.ensureActive();
    if (this.settings.vaultId) throw new Error("\u6B64 Vault \u5DF2\u7ED1\u5B9A\uFF1B\u91CD\u65B0\u5B89\u88C5\u6216\u6362\u8BBE\u5907\u524D\u8BF7\u5148\u4FDD\u7559\u540C\u6B65\u57FA\u7EBF\u4E0E\u6062\u590D\u5FEB\u7167");
    const url = normalizeServer(server, allowHttp);
    const claim = this.enrollment().claim(url, code.trim());
    const result = await Remote.pair(url, code.trim(), (0, import_node_os.hostname)(), this.transport, claim);
    this.ensureActive();
    if (this.settings.vaultId) throw new Error("\u6B64 Vault \u5DF2\u4FDD\u5B58\u53E6\u4E00\u4EFD\u7ED1\u5B9A\uFF0C\u5DF2\u505C\u6B62\u91CD\u590D\u914D\u5BF9");
    const previous = { ...this.settings };
    this.app.secretStorage.setSecret(this.settings.secretId, result.token);
    Object.assign(this.settings, { server: url, allowHttp, vaultId: result.vaultId, vaultName: result.vaultName, deviceId: result.deviceId, serverId: result.serverId, enabled: false });
    try {
      await this.saveSettings();
    } catch (e) {
      Object.assign(this.settings, previous);
      throw e;
    }
    this.ensureActive();
    this.refreshSettings();
    await this.setup();
    this.ensureActive();
    this.enrollment().complete();
    new import_obsidian3.Notice("\u914D\u5BF9\u6210\u529F\u3002\u5148\u9884\u89C8\u9996\u6B21\u540C\u6B65\uFF0C\u518D\u786E\u8BA4\u5F00\u59CB\u3002");
  }
  preview() {
    const result = this.previewFlow.run("first-sync", () => this.runPreview());
    void result.then(() => this.refreshSettings(), () => this.refreshSettings());
    return result;
  }
  async runPreview() {
    this.ensureActive();
    if (this.previewDialog) {
      await this.focusMainWindow();
      return;
    }
    this.refreshSettings();
    this.setStatus("\u6B63\u5728\u751F\u6210\u9996\u6B21\u540C\u6B65\u9884\u89C8\u2026");
    await this.setup();
    this.ensureActive();
    if (!this.engine) throw new Error("\u8BF7\u5148\u8F93\u5165\u914D\u5BF9\u7801\u8FDE\u63A5\u670D\u52A1");
    const modal = new import_obsidian3.Modal(this.app);
    modal.titleEl.setText("\u9009\u62E9\u8986\u76D6\u65B9\u5411");
    modal.onClose = () => {
      this.previewDialog = void 0;
      if (!this.engine?.state.initialized && !this.disposed) this.setStatus("\u5DF2\u914D\u5BF9\uFF0C\u9996\u6B21\u540C\u6B65\u5C1A\u672A\u5F00\u59CB");
    };
    modal.contentEl.createEl("p", { text: "\u8BF7\u9009\u62E9\u4EE5\u54EA\u4E00\u7AEF\u4E3A\u51C6\u3002\u4E0B\u4E00\u6B65\u4F1A\u5217\u51FA\u5177\u4F53\u53D8\u5316\uFF0C\u786E\u8BA4\u4E4B\u524D\u4E0D\u4F1A\u4FEE\u6539\u7B14\u8BB0\u3002\u53EA\u5904\u7406\u672A\u6392\u9664\u7684 Markdown \u6587\u4EF6\u3002" });
    if (this.engine.state.overwrite) modal.contentEl.createEl("p", { text: "\u4E0A\u6B21\u8986\u76D6\u672A\u5B8C\u6210\uFF1B\u8BF7\u91CD\u65B0\u9884\u89C8\u539F\u65B9\u5411\uFF0C\u7136\u540E\u786E\u8BA4\u7EE7\u7EED\u3002" });
    const choose = (mode) => {
      modal.close();
      void this.action(() => this.previewDirection(mode));
    };
    new import_obsidian3.Setting(modal.contentEl).setName("\u4E91\u7AEF\u8986\u76D6\u672C\u5730").setDesc("\u672C\u5730\u4F1A\u53D8\u6210\u4E91\u7AEF\u7684\u6837\u5B50\uFF0C\u672C\u5730\u72EC\u6709\u7684\u7B14\u8BB0\u4F1A\u88AB\u5220\u9664\u3002\u8BF7\u63D0\u524D\u81EA\u884C\u5907\u4EFD\u3002").addButton((b) => b.setButtonText("\u9884\u89C8\u4E91\u7AEF\u8986\u76D6").onClick(() => choose("cloud-to-local")));
    new import_obsidian3.Setting(modal.contentEl).setName("\u672C\u5730\u8986\u76D6\u4E91\u7AEF").setDesc("\u4E91\u7AEF\u4F1A\u53D8\u6210\u672C\u5730\u7684\u6837\u5B50\uFF0C\u4E91\u7AEF\u72EC\u6709\u7684\u7B14\u8BB0\u4F1A\u88AB\u5220\u9664\uFF1B\u65E7\u7248\u672C\u4FDD\u7559\u5728\u540E\u53F0\u3002").addButton((b) => b.setButtonText("\u9884\u89C8\u672C\u5730\u8986\u76D6").onClick(() => choose("local-to-cloud")));
    this.previewDialog = modal;
    try {
      await this.openMainModal(modal);
    } catch (e) {
      this.previewDialog = void 0;
      throw e;
    }
  }
  async previewDirection(mode) {
    const engine = this.engine;
    if (!engine) throw new Error("\u8BF7\u5148\u8FDE\u63A5\u540C\u6B65\u670D\u52A1");
    this.setStatus("\u6B63\u5728\u6BD4\u8F83\u672C\u5730\u4E0E\u4E91\u7AEF\u2026");
    const plan = await engine.previewOverwrite(mode);
    this.ensureActive();
    const modal = new import_obsidian3.Modal(this.app);
    modal.titleEl.setText(mode === "cloud-to-local" ? "\u786E\u8BA4\u4E91\u7AEF\u8986\u76D6\u672C\u5730" : "\u786E\u8BA4\u672C\u5730\u8986\u76D6\u4E91\u7AEF");
    modal.contentEl.addClass("lan-sync-modal");
    modal.contentEl.createEl("p", { text: `\u672C\u5730 ${plan.local} \u7BC7\uFF0C\u4E91\u7AEF ${plan.cloud} \u7BC7\uFF0C\u76F8\u540C ${plan.unchanged} \u7BC7\uFF1B\u5C06\u6267\u884C ${plan.actions.length} \u9879\u53D8\u5316\u3002` });
    const labels = { upload: "\u4E0A\u4F20 / \u8986\u76D6\u4E91\u7AEF", download: "\u4E0B\u8F7D / \u8986\u76D6\u672C\u5730", "delete-local": "\u5220\u9664\u672C\u5730", "delete-cloud": "\u5220\u9664\u4E91\u7AEF" };
    modal.contentEl.createEl("pre", { text: plan.actions.map((a) => `${labels[a.type]}\uFF1A${a.path}`).join("\n") || "\u4E24\u7AEF\u5DF2\u7ECF\u4E00\u81F4\u3002" });
    modal.contentEl.createEl("p", { text: mode === "cloud-to-local" ? "\u672C\u5730\u72EC\u6709\u7B14\u8BB0\u4F1A\u88AB\u5220\u9664\uFF0C\u540C\u540D\u7B14\u8BB0\u4F1A\u88AB\u66FF\u6362\u3002\u8BF7\u5148\u81EA\u884C\u5907\u4EFD\u6574\u4E2A\u672C\u5730\u7B14\u8BB0\u5E93\u3002" : "\u4E91\u7AEF\u5220\u9664\u548C\u8986\u76D6\u90FD\u4F1A\u751F\u6210\u65B0\u7248\u672C\uFF0C\u5386\u53F2\u7248\u672C\u53EF\u5728\u7BA1\u7406\u5458\u540E\u53F0\u67E5\u770B\u548C\u6062\u590D\u3002" });
    let backedUp = mode !== "cloud-to-local";
    if (!backedUp) new import_obsidian3.Setting(modal.contentEl).setName("\u6211\u5DF2\u81EA\u884C\u5907\u4EFD\u672C\u5730\u7B14\u8BB0\u5E93").addToggle((t) => t.onChange((value) => {
      backedUp = value;
    }));
    new import_obsidian3.Setting(modal.contentEl).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => modal.close())).addButton((b) => b.setButtonText("\u786E\u8BA4\u5E76\u5F00\u59CB\u8986\u76D6").setWarning().onClick(() => {
      if (!backedUp) {
        new import_obsidian3.Notice("\u8BF7\u5148\u81EA\u884C\u5907\u4EFD\u672C\u5730\u7B14\u8BB0\u5E93\uFF0C\u5E76\u786E\u8BA4\u5DF2\u5907\u4EFD\u3002");
        return;
      }
      b.setDisabled(true);
      void this.action(async () => {
        this.settings.enabled = false;
        await this.saveSettings();
        modal.close();
        this.refreshSettings();
        await engine.startOverwrite(plan);
        this.ensureActive();
        this.settings.enabled = true;
        await this.saveSettings();
        this.refreshSettings();
        new import_obsidian3.Notice("\u8986\u76D6\u5B8C\u6210\uFF0C\u81EA\u52A8\u540C\u6B65\u5DF2\u5F00\u542F\u3002");
      }).finally(() => {
        if (!this.disposed) {
          b.setDisabled(false);
          this.refreshSettings();
        }
      });
    }));
    await this.openMainModal(modal);
  }
  async sync(manual, periodic = false) {
    if (this.disposed || this.working) return;
    if (!this.engine && this.settings.vaultId) {
      try {
        await this.setup();
      } catch (e) {
        this.setStatus(e instanceof Error ? e.message : "\u521D\u59CB\u5316\u5931\u8D25");
        if (manual) throw e;
        return;
      }
    }
    if (!this.engine?.state.initialized) {
      if (manual) throw new Error("\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u5B8C\u6210\u914D\u5BF9\u548C\u9996\u6B21\u540C\u6B65\u9884\u89C8");
      return;
    }
    if (!manual && Date.now() < this.nextAttempt) return;
    this.working = true;
    try {
      const generation = this.localGeneration;
      const idle = periodic && generation === this.cleanGeneration && Date.now() - this.lastFullScan < 6e4;
      await this.engine.sync(idle);
      this.failures = 0;
      this.nextAttempt = 0;
      if (!idle) {
        this.cleanGeneration = generation;
        this.lastFullScan = Date.now();
      }
      if (manual) new import_obsidian3.Notice("\u5C40\u57DF\u7F51\u540C\u6B65\uFF1A" + this.status);
    } catch (e) {
      this.failures++;
      this.nextAttempt = Date.now() + Math.min(6e4, 5e3 * 2 ** Math.min(this.failures - 1, 4));
      const message = e instanceof Error ? e.message : "\u540C\u6B65\u5931\u8D25";
      this.setStatus(message);
      if (manual) new import_obsidian3.Notice(message, 8e3);
    } finally {
      this.working = false;
    }
  }
  async showIssues() {
    if (!this.engine) {
      new import_obsidian3.Notice("\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u8FDE\u63A5\u540C\u6B65\u670D\u52A1");
      return;
    }
    const engine = this.engine, modal = new import_obsidian3.Modal(this.app);
    modal.titleEl.setText("\u540C\u6B65\u5F85\u5904\u7406\u9879");
    modal.contentEl.addClass("lan-sync-modal");
    const state = engine.state;
    const plan = state.deletePlan;
    if (plan) {
      const section = modal.contentEl.createDiv("lan-sync-card");
      section.createEl("h3", { text: `${plan.direction === "local" ? "\u4E0A\u4F20" : "\u63A5\u6536"}\u6279\u91CF\u5220\u9664\uFF1A${plan.paths.length} \u7BC7` });
      section.createEl("pre", { text: plan.paths.join("\n") });
      new import_obsidian3.Setting(section).addButton((b) => b.setButtonText("\u786E\u8BA4\u8FD9\u6279\u5220\u9664\u5E76\u540C\u6B65").setWarning().onClick(() => {
        modal.close();
        void this.action(async () => {
          await engine.approveDeletes();
          await this.sync(true);
        });
      }));
    }
    const issues = Object.entries(state.issues).filter(([fileId]) => fileId !== "__deletes__");
    if (!issues.length && !plan) {
      const held = state.pending.filter((p) => engine.isExcluded(p.revision.path) || engine.isExcluded(state.entries[p.revision.fileId]?.path ?? p.revision.path)).length;
      modal.contentEl.createEl("p", { text: state.pending.length ? `\u5F85\u4E0A\u4F20 ${state.pending.length - held} \u9879\uFF1B${held} \u9879\u56E0\u6392\u9664\u89C4\u5219\u6682\u505C\uFF0C\u539F\u5FEB\u7167\u4FDD\u7559\u5728\u672C\u5730\u3002` : "\u5F53\u524D\u6CA1\u6709\u51B2\u7A81\u6216\u5F85\u5904\u7406\u9879\u3002" });
    }
    for (const [fileId, message] of issues) {
      const entry = state.entries[fileId], file = state.remote[fileId];
      const card = modal.contentEl.createDiv("lan-sync-card");
      card.createEl("h3", { text: entry?.path ?? file?.heads[0]?.path ?? fileId });
      card.createEl("p", { text: message });
      if (!file) {
        if (entry && state.pending.some((p) => p.revision.fileId === fileId)) {
          card.createEl("p", { text: "\u82E5\u4E3A\u65B0\u6587\u4EF6\u91CD\u540D\uFF0C\u8BF7\u5148\u5728 Obsidian \u4E2D\u6539\u540D\uFF0C\u518D\u70B9\u51FB\u91CD\u8BD5\u3002" });
          new import_obsidian3.Setting(card).addButton((b) => b.setButtonText("\u91CD\u8BD5\u6539\u540D\u540E\u7684\u65B0\u6587\u4EF6").onClick(() => {
            modal.close();
            void this.action(async () => {
              await engine.retryRenamed(fileId);
              await this.sync(true);
            });
          }));
        }
        continue;
      }
      if (entry) new import_obsidian3.Setting(card).setName("\u4F7F\u7528\u672C\u5730\u5F53\u524D\u5185\u5BB9").setDesc("\u63D0\u4EA4\u4E3A\u65B0\u7684\u89E3\u51B3\u7248\u672C\uFF1B\u672C\u5730\u7F3A\u5931\u8868\u793A\u5220\u9664\u3002").addButton((b) => b.setButtonText("\u9009\u62E9\u672C\u5730").onClick(() => this.confirmResolution(modal, fileId, "local", "\u672C\u5730\u5F53\u524D\u5185\u5BB9")));
      for (const head of file.heads) new import_obsidian3.Setting(card).setName(head.deleted ? "\u8FDC\u7AEF\u5220\u9664\u7248\u672C" : head.path).setDesc(`${head.id.slice(0, 8)} \xB7 ${head.size} \u5B57\u8282`).addButton((b) => b.setButtonText("\u9884\u89C8 / \u9009\u62E9").onClick(() => void this.action(() => this.previewRevision(modal, fileId, head))));
    }
    modal.contentEl.createEl("p", { text: "\u9009\u62E9\u7248\u672C\u4F1A\u4FDD\u7559\u5DF2\u63D0\u4EA4\u7684\u5386\u53F2\uFF1B\u88AB\u66FF\u6362\u7684\u672C\u5730\u5185\u5BB9\u53E6\u5B58\u4E8E\u63D2\u4EF6 local-state/snapshots \u6062\u590D\u76EE\u5F55\u3002\u6253\u5F00\u4E2D\u7684\u7B14\u8BB0\u4F1A\u7B49\u5F85\u5173\u95ED\u540E\u518D\u5E94\u7528\u3002" });
    modal.open();
  }
  confirmResolution(parent, fileId, choice, label) {
    const modal = new import_obsidian3.Modal(this.app);
    modal.titleEl.setText("\u786E\u8BA4\u4F7F\u7528\u6240\u9009\u7248\u672C");
    modal.contentEl.createEl("p", { text: `\u5C06\u4F7F\u7528\u201C${label}\u201D\u521B\u5EFA\u65B0\u7248\u672C\u3002\u539F\u7248\u672C\u4FDD\u7559\uFF0C\u53EF\u4ECE\u5386\u53F2\u6062\u590D\u3002` });
    new import_obsidian3.Setting(modal.contentEl).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => modal.close())).addButton((b) => b.setButtonText("\u786E\u8BA4\u9009\u62E9").setCta().onClick(() => {
      b.setDisabled(true);
      void this.action(async () => {
        await this.engine.resolve(fileId, choice);
        modal.close();
        parent.close();
        await this.sync(true);
      }).finally(() => {
        if (!this.disposed) b.setDisabled(false);
      });
    }));
    modal.open();
  }
  async previewRevision(parent, fileId, revision) {
    const data = revision.deleted ? null : await this.engine.remote.get(revision.hash);
    const modal = new import_obsidian3.Modal(this.app);
    modal.titleEl.setText(revision.deleted ? "\u5220\u9664\u7248\u672C" : revision.path);
    modal.contentEl.addClass("lan-sync-modal");
    modal.contentEl.createEl("pre", { text: data ? data.toString("utf8").slice(0, 12e3) : "\u6B64\u7248\u672C\u8868\u793A\u5220\u9664\uFF1B\u9009\u62E9\u540E\u6587\u4EF6\u4F1A\u8FDB\u5165\u56DE\u6536\u7AD9\u3002" });
    new import_obsidian3.Setting(modal.contentEl).addButton((b) => b.setButtonText("\u9009\u62E9\u8FD9\u4E2A\u7248\u672C").setCta().onClick(() => {
      modal.close();
      this.confirmResolution(parent, fileId, revision, revision.id.slice(0, 8));
    }));
    modal.open();
  }
};
